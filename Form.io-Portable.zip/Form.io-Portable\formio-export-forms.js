/**
 * form.io – Formulardefinitionen exportieren (für Git)
 * ---------------------------------------------------------------------
 * Lädt die Definitionen aller Formulare einer Umgebung (Felder, Layout,
 * Einstellungen) und speichert sie je Formular ab:
 *   <out>/<env>/<formPath>.json           Formulardefinition
 *   <out>/<env>/<formPath>.actions.json   Aktionen (Webhooks, E-Mail, ...)
 *   <out>/<env>/roles.json                Rollen (für das Zuordnen beim Transport)
 *
 * Der Ordner lässt sich direkt als Git-Repository nutzen. Mit --commit
 * werden Änderungen anschließend automatisch committet.
 *
 * Nutzung:
 *   node formio-export-forms.js --env=rps.prod
 *     -> exportiert alle Formulare nach ./forms/rps.prod/
 *
 *   node formio-export-forms.js --env=rps.prod --out=../rps-formulare --commit
 *     -> eigenes Git-Repository als Ziel, danach git add + commit bei Änderungen
 *
 *   node formio-export-forms.js --env=rps.prod --form=kontaktformular,antrag
 *     -> nur bestimmte Formulare (Pfade, kommagetrennt); löscht dann nichts
 *
 * Parameter:
 *   --env=<name>     lädt ".env.<name>" statt ".env" (wie formio-weekly-stats.js)
 *   --out=<dir>      Zielordner (Standard: "./forms")
 *   --form=<path>[,<path>...]  nur diese Formulare exportieren
 *   --commit         Änderungen im Zielordner per git committen
 *
 * Hinweis: Beim vollständigen Export werden JSON-Dateien von Formularen
 * entfernt, die in form.io nicht mehr existieren (damit das Repository
 * den Stand von form.io spiegelt).
 * ---------------------------------------------------------------------
 */
const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");
const { execFileSync } = require("child_process");

const { buildConfigFromEnvObject, createClient } = require("./lib/formio-client");

function argValue(name) {
  const arg = process.argv.find((a) => a.startsWith(`--${name}=`));
  return arg ? arg.slice(name.length + 3) : null;
}

function hasFlag(name) {
  return process.argv.includes(`--${name}`);
}

const envName = argValue("env");
const envFile = envName ? `.env.${envName}` : ".env";
const envPath = path.resolve(__dirname, envFile);

if (!fs.existsSync(envPath)) {
  console.error(`Fehler: Konnte "${envFile}" nicht finden (${envPath}).`);
  process.exit(1);
}

const parsedEnv = dotenv.parse(fs.readFileSync(envPath, "utf-8"));
console.log(`✔ Konfiguration geladen aus: ${envFile}`);

const CUSTOMER = process.env.FORMIO_CUSTOMER || (envName ? envName.split(".")[0] : "default");
// Ordnername = Umgebung (z.B. "rps.dev"), sonst Kundenname
const FOLDER = envName || CUSTOMER;
const OUT_DIR = argValue("out") || "./forms";
const COMMIT = hasFlag("commit");
const ROLES_FILE = "roles.json";

function sanitizeForFilename(value) {
  return String(value).replace(/[^a-zA-Z0-9._-]/g, "_");
}

function writeJson(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2) + "\n", "utf-8");
}

function git(cwd, args) {
  return execFileSync("git", args, { cwd, encoding: "utf-8", stdio: ["ignore", "pipe", "pipe"] }).trim();
}

/** Committet alle Änderungen im Zielordner (nur dort, nicht im restlichen Repo). */
function commitChanges(dir, customer) {
  try {
    git(dir, ["rev-parse", "--is-inside-work-tree"]);
  } catch {
    throw new Error(`--commit: "${dir}" ist kein Git-Repository. Bitte vorher "git init" ausführen.`);
  }

  git(dir, ["add", "-A", "--", "."]);
  const changes = git(dir, ["status", "--porcelain", "--", "."]);
  if (!changes) {
    console.log("✔ Keine Änderungen gegenüber dem letzten Commit.");
    return;
  }

  const date = new Date().toISOString().slice(0, 10);
  git(dir, ["commit", "-m", `Formulardefinitionen ${customer} (${date})`, "--", "."]);
  console.log(`✔ Commit erstellt:\n${changes.split("\n").map((l) => "    " + l).join("\n")}`);
}

async function main() {
  const config = buildConfigFromEnvObject(parsedEnv, { customer: CUSTOMER, envFile });
  const client = createClient(config);

  const allForms = await client.getForms();
  if (allForms.length === 0) {
    throw new Error("Keine Formulare gefunden.");
  }

  const formFilter = argValue("form");
  const wanted = formFilter ? formFilter.split(",").map((s) => s.trim()).filter(Boolean) : null;
  const forms = wanted ? allForms.filter((f) => wanted.includes(f.path)) : allForms;

  if (wanted) {
    const missing = wanted.filter((p) => !allForms.some((f) => f.path === p));
    if (missing.length > 0) {
      throw new Error(`Formular(e) nicht gefunden: ${missing.join(", ")}`);
    }
  }

  // Ein Ordner pro Umgebung (rps.dev, rps.prod), damit sich Quelle und Ziel nicht überschreiben.
  const targetDir = path.resolve(__dirname, OUT_DIR, FOLDER);
  fs.mkdirSync(targetDir, { recursive: true });

  const written = new Set();
  for (const form of forms) {
    console.log(`→ Lade Formular "${form.title}" (${form.path})...`);
    const base = sanitizeForFilename(form.path);

    const definition = await client.getFormDefinition(form.path);
    writeJson(path.join(targetDir, `${base}.json`), definition);
    written.add(`${base}.json`);

    const actions = await client.getActions(form.path);
    writeJson(path.join(targetDir, `${base}.actions.json`), actions);
    written.add(`${base}.actions.json`);
  }
  console.log(`✔ ${written.size / 2} Formular(e) mit Aktionen gespeichert in: ${targetDir}`);

  // Rollen immer mitexportieren: Der Transport braucht sie zum Zuordnen der Zugriffsrechte.
  const roles = await client.getRoles();
  writeJson(
    path.join(targetDir, ROLES_FILE),
    roles
      .map((r) => ({ _id: r._id, title: r.title, machineName: r.machineName }))
      .sort((a, b) => String(a.machineName).localeCompare(String(b.machineName)))
  );
  console.log(`✔ ${roles.length} Rolle(n) gespeichert.`);

  if (!wanted) {
    for (const file of fs.readdirSync(targetDir)) {
      // roles.json und stage.json gehören nicht zu den Formularen und bleiben daher stehen
      if (file.endsWith(".json") && file !== ROLES_FILE && file !== "stage.json" && !written.has(file)) {
        fs.unlinkSync(path.join(targetDir, file));
        console.log(`✖ Entfernt (in form.io nicht mehr vorhanden): ${file}`);
      }
    }
  }

  if (COMMIT) {
    commitChanges(targetDir, FOLDER);
  }
}

main().catch((err) => {
  console.error("Fehler:", err.message);
  process.exit(1);
});
