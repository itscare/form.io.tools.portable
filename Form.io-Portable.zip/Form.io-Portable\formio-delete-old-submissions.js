/**
 * form.io – Submissions löschen, die älter als X Tage sind
 * ---------------------------------------------------------------------
 * Wählt Submissions anhand des Felds "created" aus und löscht sie. Vor jedem
 * Löschen wird die vollständige Submission nach
 *   backups/<env>/submissions-<zeitstempel>/<formPath>/<id>.json
 * gesichert. Schlägt eine Sicherung fehl, wird die Submission nicht gelöscht
 * und der Lauf bricht ab.
 *
 * Ohne --execute läuft nur ein Trockenlauf: Es wird angezeigt, was gelöscht
 * würde, aber nichts geändert.
 *
 * Nutzung:
 *   node formio-delete-old-submissions.js --env=rps.dev --days=365 --form=antrag
 *     -> Trockenlauf für ein Formular
 *
 *   node formio-delete-old-submissions.js --env=rps.dev --days=365 --form=antrag --execute
 *     -> löscht nach Sicherung und Bestätigung ("loeschen" eingeben)
 *
 *   node formio-delete-old-submissions.js --env=rps.dev --days=365 --all-forms
 *     -> Trockenlauf für alle Formulare der Umgebung
 *
 * Parameter:
 *   --env=<name>       Pflicht, lädt ".env.<name>"
 *   --days=<X>         Pflicht, ganze Zahl: Submissions älter als X Tage
 *   --form=<pfad>[,..] Formulare auswählen, oder
 *   --all-forms        alle Formulare der Umgebung
 *   --execute          tatsächlich löschen (ohne Flag nur Trockenlauf)
 *   --yes              Bestätigungsabfrage überspringen (für Automatisierung)
 * ---------------------------------------------------------------------
 */
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const dotenv = require("dotenv");

const { buildConfigFromEnvObject, createClient } = require("./lib/formio-client");

const DAY_MS = 24 * 60 * 60 * 1000;
const PAGE_SIZE = 1000;
const CONFIRM_WORD = "loeschen";

function argValue(name) {
  const arg = process.argv.find((a) => a.startsWith(`--${name}=`));
  return arg ? arg.slice(name.length + 3) : null;
}

function hasFlag(name) {
  return process.argv.includes(`--${name}`);
}

function sanitizeForFilename(value) {
  return String(value).replace(/[^a-zA-Z0-9._-]/g, "_");
}

function loadEnvConfig(envName) {
  const envFile = `.env.${envName}`;
  const envPath = path.resolve(__dirname, envFile);
  if (!fs.existsSync(envPath)) {
    throw new Error(`Konfigurationsdatei "${envFile}" nicht gefunden.`);
  }
  const parsed = dotenv.parse(fs.readFileSync(envPath, "utf-8"));
  return buildConfigFromEnvObject(parsed, { customer: envName.split(".")[0], envFile });
}

/** Grenzdatum: Submissions mit created vor diesem Zeitpunkt gelten als alt. */
function cutoffFor(days, now = Date.now()) {
  return new Date(now - days * DAY_MS);
}

/** Alle Submissions eines Formulars, die vor dem Grenzdatum erstellt wurden. Liest alle Seiten, bevor etwas gelöscht wird. */
async function collectOldSubmissions(client, formPath, cutoff) {
  const old = [];
  let skip = 0;
  while (true) {
    const page = await client.listSubmissions(formPath, skip, PAGE_SIZE);
    for (const submission of page) {
      if (new Date(submission.created) < cutoff) old.push(submission);
    }
    if (page.length < PAGE_SIZE) break;
    skip += PAGE_SIZE;
  }
  return old;
}

/** Sichert und löscht Submissions einzeln. Ohne erfolgreiche Sicherung wird nicht gelöscht. */
async function deleteWithBackup(client, formPath, submissions, backupDir, onProgress = () => {}) {
  let deleted = 0;
  for (const submission of submissions) {
    const file = path.join(backupDir, sanitizeForFilename(formPath), `${sanitizeForFilename(submission._id)}.json`);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(submission, null, 2) + "\n", "utf-8");
    if (!fs.existsSync(file)) {
      throw new Error(`Sicherung von ${submission._id} fehlgeschlagen, Lauf abgebrochen.`);
    }
    await client.deleteSubmission(formPath, submission._id);
    deleted++;
    onProgress(deleted);
  }
  return deleted;
}

function ask(rl, question) {
  return new Promise((resolve) => rl.question(question, resolve));
}

async function confirmDeletion(envName, total, backupDir) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await ask(
      rl,
      `\n${total} Submission(s) in "${envName}" werden endgültig gelöscht (Sicherung in ${backupDir}).\n` +
        `Zum Bestätigen "${CONFIRM_WORD}" eingeben: `
    );
    return answer.trim() === CONFIRM_WORD;
  } finally {
    rl.close();
  }
}

async function main() {
  const envName = argValue("env");
  const days = Number(argValue("days"));
  if (!envName) throw new Error("Bitte --env=<name> angeben, z.B. --env=rps.dev.");
  if (!Number.isInteger(days) || days < 1) throw new Error("--days muss eine ganze Zahl ab 1 sein.");

  const formArg = argValue("form");
  if (!formArg && !hasFlag("all-forms")) {
    throw new Error("Bitte --form=<pfad> oder --all-forms angeben. Ohne Auswahl wird nichts gelöscht.");
  }

  const client = createClient(loadEnvConfig(envName));
  const allForms = (await client.listAllForms()).map((f) => f.path);
  let formPaths = allForms;
  if (formArg) {
    formPaths = formArg.split(",").map((s) => s.trim()).filter(Boolean);
    const missing = formPaths.filter((p) => !allForms.includes(p));
    if (missing.length > 0) throw new Error(`Formular(e) nicht gefunden: ${missing.join(", ")}`);
  }

  const cutoff = cutoffFor(days);
  console.log(`Grenzdatum: Submissions vor ${cutoff.toLocaleString("de-DE")} (älter als ${days} Tage)`);

  const plan = [];
  for (const formPath of formPaths) {
    const old = await collectOldSubmissions(client, formPath, cutoff);
    if (old.length > 0) plan.push({ formPath, submissions: old });
    console.log(`  • ${formPath}: ${old.length} alte Submission(s)`);
  }
  const total = plan.reduce((sum, p) => sum + p.submissions.length, 0);
  if (total === 0) {
    console.log("Keine Submissions zum Löschen gefunden.");
    return;
  }

  if (!hasFlag("execute")) {
    console.log(`\nTrockenlauf: ${total} Submission(s) würden gelöscht. Mit --execute wird wirklich gelöscht.`);
    return;
  }

  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupDir = path.resolve(__dirname, "backups", envName, `submissions-${stamp}`);
  if (!hasFlag("yes") && !(await confirmDeletion(envName, total, backupDir))) {
    console.log("Abgebrochen. Es wurde nichts gelöscht.");
    return;
  }

  let deletedTotal = 0;
  for (const { formPath, submissions } of plan) {
    console.log(`→ ${formPath}: lösche ${submissions.length} Submission(s)...`);
    deletedTotal += await deleteWithBackup(client, formPath, submissions, backupDir, (n) => {
      if (n % 100 === 0) console.log(`  … ${n} gelöscht`);
    });
  }
  console.log(`\n✔ ${deletedTotal} Submission(s) gelöscht. Sicherung: ${backupDir}`);
}

module.exports = { cutoffFor, collectOldSubmissions, deleteWithBackup };

if (require.main === module) {
  main().catch((err) => {
    console.error("Fehler:", err.message);
    process.exit(1);
  });
}
