/**
 * form.io – Einzelne Submission(s) per ID herunterladen
 * ---------------------------------------------------------------------
 * Lädt die JSON-Daten einer (oder mehrerer) konkreter Submission(s) anhand
 * ihrer Submission-ID und speichert sie lokal ab. Nutzt dieselbe
 * .env-Konfiguration (Auth, Proxy, Retry) wie formio-weekly-stats.js.
 *
 * Nutzung:
 *   node formio-get-submission.js --env=rps.prod
 *     -> fragt interaktiv nach Formular (Auswahl aus Liste) und Submission-ID(s)
 *
 *   node formio-get-submission.js --env=rps.prod --form=kontaktformular --id=65f1...
 *     -> ohne Rückfrage direkt abrufen
 *
 *   node formio-get-submission.js --env=rps.prod --form=kontaktformular --id=65f1...,65f2...
 *     -> mehrere Submission-IDs (kommagetrennt) auf einmal
 *
 * Parameter:
 *   --env=<name>   lädt ".env.<name>" statt ".env" (wie formio-weekly-stats.js)
 *   --form=<path>  Formular-Pfad (überspringt die interaktive Auswahl)
 *   --id=<id>[,<id>...]  eine oder mehrere Submission-IDs (überspringt die Abfrage)
 *   --out=<dir>    Zielordner (Standard: "./submissions")
 * ---------------------------------------------------------------------
 */
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const dotenv = require("dotenv");

const { buildConfigFromEnvObject, createClient } = require("./lib/formio-client");

function argValue(name) {
  const arg = process.argv.find((a) => a.startsWith(`--${name}=`));
  return arg ? arg.slice(name.length + 3) : null;
}

const envName = argValue("env");
const envFile = envName ? `.env.${envName}` : ".env";
const envPath = path.resolve(__dirname, envFile);

if (!fs.existsSync(envPath)) {
  console.error(`Fehler: Konnte "${envFile}" nicht finden (${envPath}).`);
  process.exit(1);
}

const parsedEnv = dotenv.parse(fs.readFileSync(envPath, "utf-8"));
console.log(`✔ Konfiguration geladen aus: ${envFile}`);

const CUSTOMER = process.env.FORMIO_CUSTOMER || (envName ? envName.split(".")[0] : "default");
const OUT_DIR = argValue("out") || "./submissions";

function ask(rl, question) {
  return new Promise((resolve) => rl.question(question, resolve));
}

function sanitizeForFilename(value) {
  return String(value).replace(/[^a-zA-Z0-9._-]/g, "_");
}

async function chooseForm(client, presetFormPath) {
  const forms = await client.getForms();
  if (forms.length === 0) {
    throw new Error("Keine Formulare gefunden.");
  }

  if (presetFormPath) {
    const match = forms.find((f) => f.path === presetFormPath);
    if (!match) {
      throw new Error(
        `Formular "${presetFormPath}" wurde nicht gefunden. Verfügbar: ${forms.map((f) => f.path).join(", ")}`
      );
    }
    return match;
  }

  console.log("\nVerfügbare Formulare:");
  forms.forEach((f, i) => console.log(`  [${i + 1}] ${f.title}  (${f.path})`));

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    while (true) {
      const answer = await ask(rl, "\nFormular wählen (Nummer): ");
      const index = Number(answer.trim()) - 1;
      if (Number.isInteger(index) && index >= 0 && index < forms.length) {
        return forms[index];
      }
      console.log("Ungültige Auswahl, bitte erneut versuchen.");
    }
  } finally {
    rl.close();
  }
}

async function collectSubmissionIds(presetIds) {
  if (presetIds) {
    return presetIds.split(",").map((s) => s.trim()).filter(Boolean);
  }

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await ask(rl, "Submission-ID(n), kommagetrennt bei mehreren: ");
    const ids = answer.split(",").map((s) => s.trim()).filter(Boolean);
    if (ids.length === 0) {
      throw new Error("Keine Submission-ID eingegeben.");
    }
    return ids;
  } finally {
    rl.close();
  }
}

async function main() {
  const config = buildConfigFromEnvObject(parsedEnv, { customer: CUSTOMER, envFile });
  const client = createClient(config);

  const form = await chooseForm(client, argValue("form"));
  console.log(`✔ Formular: ${form.title} (${form.path})`);

  const ids = await collectSubmissionIds(argValue("id"));

  const targetDir = path.resolve(__dirname, OUT_DIR, CUSTOMER);
  fs.mkdirSync(targetDir, { recursive: true });

  for (const id of ids) {
    console.log(`→ Lade Submission "${id}"...`);
    const submission = await client.getSubmission(form.path, id);
    const filePath = path.join(
      targetDir,
      `${sanitizeForFilename(form.path)}_${sanitizeForFilename(id)}.json`
    );
    fs.writeFileSync(filePath, JSON.stringify(submission, null, 2), "utf-8");
    console.log(`✔ Gespeichert: ${filePath}`);
  }
}

main().catch((err) => {
  console.error("Fehler:", err.message);
  process.exit(1);
});
