@echo off
rem Oeffnet eine Eingabeaufforderung, in der "node" die mitgelieferte Version nutzt.
rem Beispiele:
rem   node formio-get-submission.js --env=rps.prod --form=<pfad> --id=<id>
rem   node formio-export-forms.js --env=rps.prod
rem   node formio-export-stage.js --env=rps.prod
cd /d "%~dp0"
set "PATH=%~dp0node;%PATH%"
echo Node-Version:
node --version
echo.
cmd /k
