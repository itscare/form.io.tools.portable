@echo off
rem Startet das Statistik-Dashboard (server.js) mit der mitgelieferten Node-Version.
cd /d "%~dp0"
set "PATH=%~dp0node;%PATH%"
if not exist "Reports" mkdir "Reports"
set "PORT=3000"
echo.
echo Dashboard startet auf http://localhost:3000
echo Zum Beenden dieses Fenster schliessen oder STRG+C druecken.
echo.
node server.js
echo.
echo Das Dashboard wurde beendet.
pause
