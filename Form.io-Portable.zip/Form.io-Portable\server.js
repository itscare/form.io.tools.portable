/**
 * Kleines Dashboard für die form.io-Wochenstatistik (RPS/HE/BW).
 * Liest ausschließlich aus stats.db (siehe lib/db.js), die von
 * formio-weekly-stats.js bei jedem Abruf aktualisiert wird.
 *
 * Start:  npm run web   (Standard-Port 3000, konfigurierbar über PORT)
 */
const fs = require("fs");
const path = require("path");
const express = require("express");
const {
  getCustomers,
  getStatsForCustomer,
  getWeeklyTotals,
  getMonthlyStatsForCustomer,
  getMonthlyTotals,
  getHeatmapForCustomer,
  getSourcesForCustomer,
  getLastFetch,
} = require("./lib/db");
const dotenv = require("dotenv");
const { loadCustomerConfig, buildConfigFromEnvObject, createClient } = require("./lib/formio-client");
const { sanitizeStage, STAGE_FILE } = require("./formio-export-stage");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "public")));
app.use("/vendor", express.static(path.join(__dirname, "node_modules", "chart.js", "dist")));

app.get("/api/customers", (req, res) => {
  res.json(getCustomers());
});

app.get("/api/stats/:customer", (req, res) => {
  res.json(getStatsForCustomer(req.params.customer));
});

app.get("/api/summary", (req, res) => {
  res.json(getWeeklyTotals());
});

app.get("/api/monthly/:customer", (req, res) => {
  res.json(getMonthlyStatsForCustomer(req.params.customer));
});

app.get("/api/monthly-summary", (req, res) => {
  res.json(getMonthlyTotals());
});

app.get("/api/heatmap/:customer", (req, res) => {
  res.json(getHeatmapForCustomer(req.params.customer));
});

app.get("/api/sources/:customer", (req, res) => {
  res.json(getSourcesForCustomer(req.params.customer));
});

app.get("/api/last-fetch", (req, res) => {
  res.json(getLastFetch());
});

// --- Live-Abruf gegen form.io (nicht aus stats.db, sondern direkt vom Projekt) ---

app.get("/api/live-forms/:customer", async (req, res) => {
  try {
    const config = loadCustomerConfig(req.params.customer);
    const forms = await createClient(config).getForms();
    res.json(forms);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.get("/api/submission/:customer/:formPath/:submissionId", async (req, res) => {
  try {
    const config = loadCustomerConfig(req.params.customer);
    const submission = await createClient(config).getSubmission(
      req.params.formPath,
      req.params.submissionId
    );
    const filename = `${req.params.customer}_${req.params.formPath}_${req.params.submissionId}.json`.replace(
      /[^a-zA-Z0-9._-]/g,
      "_"
    );
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.json(submission);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.get("/api/form/:customer/:formPath", async (req, res) => {
  try {
    const config = loadCustomerConfig(req.params.customer);
    const definition = await createClient(config).getFormDefinition(req.params.formPath);
    const filename = `${req.params.customer}_${req.params.formPath}.json`.replace(/[^a-zA-Z0-9._-]/g, "_");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.json(definition);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// --- Stage-Konfiguration aus den exportierten Dateien (forms/<env>/stage.json) ---

const FORMS_DIR = path.join(__dirname, "forms");
// Nur Umgebungsnamen wie "rps.dev" zulassen, damit kein fremder Pfad gelesen werden kann
const ENV_NAME_PATTERN = /^[a-z0-9]+(\.[a-z0-9]+)*$/i;

app.get("/api/stage-envs", (req, res) => {
  if (!fs.existsSync(FORMS_DIR)) return res.json([]);
  const envs = fs
    .readdirSync(FORMS_DIR, { withFileTypes: true })
    .filter((d) => d.isDirectory() && ENV_NAME_PATTERN.test(d.name))
    .filter((d) => fs.existsSync(path.join(FORMS_DIR, d.name, "stage.json")))
    .map((d) => d.name)
    .sort();
  res.json(envs);
});

app.get("/api/stage/:env", (req, res) => {
  const env = req.params.env;
  if (!ENV_NAME_PATTERN.test(env)) {
    return res.status(400).json({ error: "Ungültiger Umgebungsname." });
  }
  const filePath = path.join(FORMS_DIR, env, "stage.json");
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: `Keine stage.json für "${env}" gefunden.` });
  }
  try {
    const stage = JSON.parse(fs.readFileSync(filePath, "utf-8"));
    res.json({
      config: stage.config || {},
      public: {
        formModule: (stage.public && stage.public.formModule) || "",
        custom: (stage.public && stage.public.custom) || {},
      },
    });
  } catch (err) {
    res.status(500).json({ error: `stage.json konnte nicht gelesen werden: ${err.message}` });
  }
});

// Holt die aktuelle Stage-Konfiguration live von form.io und überschreibt forms/<env>/stage.json.
// Dieselbe Bereinigung wie formio-export-stage.js (Geheimnisse werden ersetzt).
app.post("/api/stage/:env/refresh", async (req, res) => {
  const env = req.params.env;
  if (!ENV_NAME_PATTERN.test(env)) {
    return res.status(400).json({ error: "Ungültiger Umgebungsname." });
  }
  const envFile = `.env.${env}`;
  const envPath = path.join(__dirname, envFile);
  if (!fs.existsSync(envPath)) {
    return res.status(404).json({ error: `Konfigurationsdatei "${envFile}" nicht gefunden.` });
  }
  try {
    const parsed = dotenv.parse(fs.readFileSync(envPath, "utf-8"));
    const config = buildConfigFromEnvObject(parsed, { customer: env.split(".")[0], envFile });
    const project = await createClient(config).getProject();
    const { data, redacted } = sanitizeStage(project);

    const targetDir = path.join(FORMS_DIR, env);
    fs.mkdirSync(targetDir, { recursive: true });
    fs.writeFileSync(path.join(targetDir, STAGE_FILE), JSON.stringify(data, null, 2) + "\n", "utf-8");
    res.json({ updatedAt: new Date().toISOString(), redacted });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`✔ Dashboard läuft auf http://localhost:${PORT}`);
});
