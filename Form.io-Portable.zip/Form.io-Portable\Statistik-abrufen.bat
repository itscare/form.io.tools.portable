@echo off
rem Ruft die Wochen-/Monatsstatistik fuer eine Umgebung ab (formio-weekly-stats.js).
cd /d "%~dp0"
set "PATH=%~dp0node;%PATH%"
if not exist "Reports" mkdir "Reports"
echo.
echo Beispiele fuer Umgebungen: rps.prod, he.prod, bw.prod
echo Es wird die Datei .env.^<Umgebung^> aus diesem Ordner verwendet.
echo.
set /p "ENVNAME=Umgebung eingeben: "
if "%ENVNAME%"=="" (
  echo Keine Umgebung angegeben.
  pause
  exit /b 1
)
if not exist ".env.%ENVNAME%" (
  echo Die Datei .env.%ENVNAME% fehlt. Bitte aus .env.example anlegen.
  pause
  exit /b 1
)
node formio-weekly-stats.js --env=%ENVNAME%
echo.
echo Abruf beendet.
pause
