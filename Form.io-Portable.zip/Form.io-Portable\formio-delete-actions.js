/**
 * form.io – Aktionen mit Methode DELETE finden und entfernen
 * ---------------------------------------------------------------------
 * Prüft die Aktionen (Webhooks, E-Mail, ...) der Formulare auf die Methode
 * DELETE und entfernt sie auf Wunsch.
 *
 * Erkannt wird eine Aktion, wenn
 *   - "delete" in der Liste der Auslöser (action.method) steht, oder
 *   - die HTTP-Methode der Aktion (action.settings.method) DELETE ist.
 *
 * Was beim Löschen passiert:
 *   - HTTP-Methode DELETE (settings.method)      -> die ganze Aktion wird gelöscht
 *   - nur Auslöser "delete"                       -> die ganze Aktion wird gelöscht
 *   - Auslöser "delete" zusammen mit anderen      -> nur "delete" wird entfernt,
 *                                                    die Aktion bleibt bestehen
 *
 * Vor jeder Änderung wird die Aktion nach
 *   backups/<env>/actions-<zeitstempel>/<formPath>/<id>.json
 * gesichert. Schlägt eine Sicherung fehl, wird nichts geändert.
 *
 * Ohne --execute läuft nur ein Trockenlauf: Es wird angezeigt, was geändert
 * würde, aber nichts geändert.
 *
 * Nutzung:
 *   node formio-delete-actions.js --env=rps.dev --all-forms
 *     -> Trockenlauf für alle Formulare der Umgebung
 *
 *   node formio-delete-actions.js --env=rps.dev --form=antrag,kontakt --execute
 *     -> ändert nach Sicherung und Bestätigung ("loeschen" eingeben)
 *
 * Parameter:
 *   --env=<name>       Pflicht, lädt ".env.<name>"
 *   --form=<pfad>[,..] Formulare auswählen, oder
 *   --all-forms        alle Formulare der Umgebung
 *   --type=<name>      nur Aktionen dieses Typs prüfen, z.B. --type=webhook
 *                      (Typ = action.name, Webhook ist "webhook")
 *   --execute         tatsächlich ändern/löschen (ohne Flag nur Trockenlauf)
 *   --yes              Bestätigungsabfrage überspringen (für Automatisierung)
 * ---------------------------------------------------------------------
 */
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const dotenv = require("dotenv");

const { buildConfigFromEnvObject, createClient } = require("./lib/formio-client");

const CONFIRM_WORD = "loeschen";

function argValue(name) {
  const arg = process.argv.find((a) => a.startsWith(`--${name}=`));
  return arg ? arg.slice(name.length + 3) : null;
}

function hasFlag(name) {
  return process.argv.includes(`--${name}`);
}

function sanitizeForFilename(value) {
  return String(value).replace(/[^a-zA-Z0-9._-]/g, "_");
}

function loadEnvConfig(envName) {
  const envFile = `.env.${envName}`;
  const envPath = path.resolve(__dirname, envFile);
  if (!fs.existsSync(envPath)) {
    throw new Error(`Konfigurationsdatei "${envFile}" nicht gefunden.`);
  }
  const parsed = dotenv.parse(fs.readFileSync(envPath, "utf-8"));
  return buildConfigFromEnvObject(parsed, { customer: envName.split(".")[0], envFile });
}

/** Prüft, ob eine Aktion die Methode DELETE verwendet (Auslöser oder HTTP-Methode). */
function deleteMatch(action) {
  const triggers = Array.isArray(action.method) ? action.method : [];
  const triggerDelete = triggers.some((m) => String(m).toLowerCase() === "delete");
  const httpDelete = String(action.settings?.method ?? "").toUpperCase() === "DELETE";
  return { triggerDelete, httpDelete, matches: triggerDelete || httpDelete };
}

/**
 * Legt fest, was mit einer Aktion passiert:
 *   { kind: "none" }                        – kein DELETE, nichts tun
 *   { kind: "delete" }                      – ganze Aktion löschen
 *   { kind: "update", method: [...] }       – nur den Auslöser "delete" entfernen
 */
function planFor(action) {
  const { triggerDelete, httpDelete, matches } = deleteMatch(action);
  if (!matches) return { kind: "none" };
  if (httpDelete) return { kind: "delete" };

  const remaining = action.method.filter((m) => String(m).toLowerCase() !== "delete");
  return remaining.length === 0 ? { kind: "delete" } : { kind: "update", method: remaining };
}

function describePlan(plan) {
  if (plan.kind === "delete") return "Aktion löschen";
  if (plan.kind === "update") return `"delete" entfernen (bleibt: ${plan.method.join(", ")})`;
  return "";
}

function ask(rl, question) {
  return new Promise((resolve) => rl.question(question, resolve));
}

async function confirmChanges(envName, total, backupDir) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await ask(
      rl,
      `\n${total} Aktion(en) in "${envName}" werden geändert (Sicherung in ${backupDir}).\n` +
        `Zum Bestätigen "${CONFIRM_WORD}" eingeben: `
    );
    return answer.trim() === CONFIRM_WORD;
  } finally {
    rl.close();
  }
}

/** Sichert eine Aktion und wendet den Plan an. Ohne erfolgreiche Sicherung wird nicht geändert. */
async function applyWithBackup(client, formPath, action, plan, backupDir) {
  const file = path.join(backupDir, sanitizeForFilename(formPath), `${sanitizeForFilename(action._id)}.json`);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(action, null, 2) + "\n", "utf-8");
  if (!fs.existsSync(file)) {
    throw new Error(`Sicherung von Aktion ${action._id} fehlgeschlagen, Lauf abgebrochen.`);
  }

  if (plan.kind === "delete") {
    await client.deleteAction(formPath, action._id);
  } else if (plan.kind === "update") {
    await client.updateAction(formPath, action._id, { ...action, method: plan.method });
  }
}

async function main() {
  const envName = argValue("env");
  if (!envName) throw new Error("Bitte --env=<name> angeben, z.B. --env=rps.dev.");

  const formArg = argValue("form");
  if (!formArg && !hasFlag("all-forms")) {
    throw new Error("Bitte --form=<pfad> oder --all-forms angeben. Ohne Auswahl wird nichts geändert.");
  }

  // Optional nur einen Aktionstyp prüfen, z.B. "webhook" (Webhook/Premium). Der Typ steht in action.name, nicht im frei wählbaren Titel.
  const typeFilter = argValue("type");

  const client = createClient(loadEnvConfig(envName));
  const allForms = (await client.listAllForms()).map((f) => ({ path: f.path, title: f.title }));
  let forms = allForms;
  if (formArg) {
    const wanted = formArg.split(",").map((s) => s.trim()).filter(Boolean);
    const missing = wanted.filter((p) => !allForms.some((f) => f.path === p));
    if (missing.length > 0) throw new Error(`Formular(e) nicht gefunden: ${missing.join(", ")}`);
    forms = allForms.filter((f) => wanted.includes(f.path));
  }

  const plan = [];
  for (const form of forms) {
    const actions = await client.getActions(form.path);
    if (!Array.isArray(actions)) throw new Error(`Unerwartete Antwort für Aktionen von "${form.path}".`);
    for (const action of actions) {
      if (typeFilter && action.name !== typeFilter) continue;
      const p = planFor(action);
      if (p.kind === "none") continue;
      plan.push({ formPath: form.path, action, plan: p });
      console.log(
        `  • ${form.path} | ${action.title || action.name || "(ohne Titel)"} [${action._id}] ` +
          `Auslöser: ${(action.method || []).join(", ") || "-"}` +
          `${action.settings?.method ? `, HTTP: ${action.settings.method}` : ""} → ${describePlan(p)}`
      );
    }
  }

  if (plan.length === 0) {
    console.log("Keine Aktionen mit Methode DELETE gefunden.");
    return;
  }

  if (!hasFlag("execute")) {
    console.log(`\nTrockenlauf: ${plan.length} Aktion(en) würden geändert. Mit --execute wird wirklich geändert.`);
    return;
  }

  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupDir = path.resolve(__dirname, "backups", envName, `actions-${stamp}`);
  if (!hasFlag("yes") && !(await confirmChanges(envName, plan.length, backupDir))) {
    console.log("Abgebrochen. Es wurde nichts geändert.");
    return;
  }

  for (const entry of plan) {
    console.log(`→ ${entry.formPath}: ${entry.action._id} – ${describePlan(entry.plan)}`);
    await applyWithBackup(client, entry.formPath, entry.action, entry.plan, backupDir);
  }
  console.log(`\n✔ ${plan.length} Aktion(en) geändert. Sicherung: ${backupDir}`);
}

module.exports = { deleteMatch, planFor };

if (require.main === module) {
  main().catch((err) => {
    console.error("Fehler:", err.message);
    process.exit(1);
  });
}
