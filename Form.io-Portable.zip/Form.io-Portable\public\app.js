(function () {
  const CUSTOMER_LABELS = { rps: "RPS", he: "HE", bw: "BW" };
  const SERIES_VARS = [
    "--series-1", "--series-2", "--series-3", "--series-4",
    "--series-5", "--series-6", "--series-7",
  ];
  const TOP_N_FORMS = 7;

  const style = getComputedStyle(document.documentElement);
  const color = (name) => style.getPropertyValue(name).trim();
  const seriesColor = (i) => color(SERIES_VARS[i % SERIES_VARS.length]);
  const otherColor = color("--series-other");
  const textSecondary = color("--text-secondary");
  const gridline = color("--gridline");
  const surface1 = color("--surface-1");

  Chart.defaults.font.family = "system-ui, -apple-system, 'Segoe UI', sans-serif";
  Chart.defaults.font.size = 12;
  Chart.defaults.color = textSecondary;

  const tabsEl = document.getElementById("tabs");
  const toolbarEl = document.getElementById("toolbar");
  const granularityEl = document.getElementById("granularity");
  const rangeEl = document.getElementById("range");
  const kpisEl = document.getElementById("kpis");
  const contentEl = document.getElementById("content");

  const DOWNLOAD_TAB_ID = "download";
  const DOWNLOAD_CUSTOMERS = ["rps", "he", "bw"];
  const STAGE_TAB_ID = "stage";

  let customers = [];
  let summaryRows = [];
  let monthlySummaryRows = [];
  let lastFetchRows = [];
  let activeTab = "overview";
  let granularity = "week"; // "week" | "month"
  let rangeFilter = "last:12"; // "last:<n>" | "year:<jahr>" | "all"
  let chartInstance = null;
  let hostChartInstance = null;

  function periodField() {
    return granularity === "week" ? "week" : "month";
  }

  function allPeriods() {
    const rows = granularity === "week" ? summaryRows : monthlySummaryRows;
    return Array.from(new Set(rows.map((r) => r[periodField()]))).sort();
  }

  function selectedPeriods(referenceRows, field) {
    const periods = Array.from(new Set(referenceRows.map((r) => r[field]))).sort();
    if (rangeFilter.startsWith("last:")) return new Set(periods.slice(-Number(rangeFilter.slice(5))));
    if (rangeFilter.startsWith("year:")) {
      const year = rangeFilter.slice(5);
      return new Set(periods.filter((p) => p.startsWith(year)));
    }
    return new Set(periods);
  }

  function applyRange(rows, field, referenceRows) {
    const keep = selectedPeriods(referenceRows, field);
    return rows.filter((r) => keep.has(r[field]));
  }

  function renderRangeFilter() {
    const unit = granularity === "week" ? "Wochen" : "Monate";
    const lastCounts = granularity === "week" ? [4, 8, 12] : [3, 6, 12];
    const years = Array.from(new Set(allPeriods().map((p) => p.slice(0, 4)))).sort().reverse();
    const options = [
      ...lastCounts.map((n) => ({ value: `last:${n}`, label: `Letzte ${n} ${unit}` })),
      ...years.map((y) => ({ value: `year:${y}`, label: `Jahr ${y}` })),
      { value: "all", label: "Alle" },
    ];
    if (!options.some((o) => o.value === rangeFilter)) rangeFilter = "last:12";
    rangeEl.innerHTML = "";
    for (const o of options) {
      const opt = document.createElement("option");
      opt.value = o.value;
      opt.textContent = o.label;
      opt.selected = o.value === rangeFilter;
      rangeEl.appendChild(opt);
    }
  }

  function fmtDate(iso) {
    if (!iso) return "–";
    const d = new Date(iso);
    return d.toLocaleString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  }

  function label(c) {
    return CUSTOMER_LABELS[c] || c.toUpperCase();
  }

  function destroyChart() {
    if (chartInstance) {
      chartInstance.destroy();
      chartInstance = null;
    }
    if (hostChartInstance) {
      hostChartInstance.destroy();
      hostChartInstance = null;
    }
  }

  async function loadAll() {
    [customers, summaryRows, monthlySummaryRows, lastFetchRows] = await Promise.all([
      fetch("/api/customers").then((r) => r.json()),
      fetch("/api/summary").then((r) => r.json()),
      fetch("/api/monthly-summary").then((r) => r.json()),
      fetch("/api/last-fetch").then((r) => r.json()),
    ]);
    renderTabs();
    renderGranularityToggle();
    renderRangeFilter();
    renderActiveTab();
  }

  rangeEl.addEventListener("change", () => {
    rangeFilter = rangeEl.value;
    renderActiveTab();
  });

  function renderTabs() {
    const tabs = [
      { id: "overview", label: "Übersicht" },
      ...customers.map((c) => ({ id: c, label: label(c) })),
      { id: DOWNLOAD_TAB_ID, label: "Submission-Download" },
      { id: STAGE_TAB_ID, label: "Stage-Konfiguration" },
    ];
    tabsEl.innerHTML = "";
    for (const t of tabs) {
      const btn = document.createElement("button");
      btn.className = "tab";
      btn.textContent = t.label;
      btn.setAttribute("role", "tab");
      btn.setAttribute("aria-selected", String(t.id === activeTab));
      btn.addEventListener("click", () => {
        activeTab = t.id;
        renderTabs();
        renderActiveTab();
      });
      tabsEl.appendChild(btn);
    }
  }

  function renderGranularityToggle() {
    const options = [{ id: "week", label: "Woche" }, { id: "month", label: "Monat" }];
    granularityEl.innerHTML = "";
    for (const o of options) {
      const btn = document.createElement("button");
      btn.className = "seg-btn";
      btn.textContent = o.label;
      btn.setAttribute("role", "tab");
      btn.setAttribute("aria-selected", String(o.id === granularity));
      btn.addEventListener("click", () => {
        if (granularity === o.id) return;
        granularity = o.id;
        renderGranularityToggle();
        renderRangeFilter();
        renderActiveTab();
      });
      granularityEl.appendChild(btn);
    }
  }

  function renderActiveTab() {
    destroyChart();
    toolbarEl.style.display = activeTab === DOWNLOAD_TAB_ID || activeTab === STAGE_TAB_ID ? "none" : "";

    if (activeTab === DOWNLOAD_TAB_ID) {
      kpisEl.innerHTML = "";
      renderSubmissionDownload();
      return;
    }

    if (activeTab === STAGE_TAB_ID) {
      kpisEl.innerHTML = "";
      renderStage();
      return;
    }

    if (customers.length === 0) {
      kpisEl.innerHTML = "";
      contentEl.innerHTML = `<p class="empty">Noch keine Daten in stats.db. Führe z.B. "npm run start:rps-prod" aus, um die Datenbank zu befüllen.</p>`;
      return;
    }
    if (activeTab === "overview") {
      renderOverview();
    } else {
      renderCustomer(activeTab);
    }
  }

  // ---- Submission-Download: einzelne Submission per ID live von form.io laden ----
  function renderSubmissionDownload() {
    contentEl.innerHTML = `
      <div class="panel">
        <h2>Submission oder Formulardefinition herunterladen</h2>
        <div class="field-row">
          <div class="field">
            <label for="dlCustomer">Kunde</label>
            <select id="dlCustomer">
              <option value="">– wählen –</option>
              ${DOWNLOAD_CUSTOMERS.map((c) => `<option value="${c}">${label(c)}</option>`).join("")}
            </select>
          </div>
          <div class="field">
            <label for="dlForm">Formular</label>
            <select id="dlForm" disabled>
              <option value="">– zuerst Kunde wählen –</option>
            </select>
          </div>
          <div class="field">
            <label for="dlSubmissionId">Submission-ID</label>
            <input type="text" id="dlSubmissionId" placeholder="z.B. 65f1a2b3c4d5e6f7a8b9c0d1" />
          </div>
          <button class="btn" id="dlButton" disabled>Submission laden</button>
          <button class="btn secondary" id="dlDefinitionButton" disabled>Formulardefinition laden</button>
        </div>
        <div id="dlStatus"></div>
      </div>
    `;

    const customerSelect = document.getElementById("dlCustomer");
    const formSelect = document.getElementById("dlForm");
    const idInput = document.getElementById("dlSubmissionId");
    const downloadBtn = document.getElementById("dlButton");
    const definitionBtn = document.getElementById("dlDefinitionButton");
    const statusEl = document.getElementById("dlStatus");

    function setStatus(message, kind) {
      statusEl.className = kind ? `status-msg ${kind}` : "status-msg";
      statusEl.textContent = message || "";
    }

    function updateButtonState() {
      downloadBtn.disabled = !(customerSelect.value && formSelect.value && idInput.value.trim());
      definitionBtn.disabled = !(customerSelect.value && formSelect.value);
    }

    customerSelect.addEventListener("change", async () => {
      const customer = customerSelect.value;
      formSelect.innerHTML = `<option value="">– lädt... –</option>`;
      formSelect.disabled = true;
      updateButtonState();
      setStatus("");

      if (!customer) {
        formSelect.innerHTML = `<option value="">– zuerst Kunde wählen –</option>`;
        return;
      }

      try {
        const res = await fetch(`/api/live-forms/${encodeURIComponent(customer)}`);
        const forms = await res.json();
        if (!res.ok) throw new Error(forms.error || "Formulare konnten nicht geladen werden.");

        if (forms.length === 0) {
          formSelect.innerHTML = `<option value="">– keine Formulare gefunden –</option>`;
          return;
        }
        formSelect.innerHTML =
          `<option value="">– wählen –</option>` +
          forms.map((f) => `<option value="${f.path}">${f.title} (${f.path})</option>`).join("");
        formSelect.disabled = false;
      } catch (err) {
        formSelect.innerHTML = `<option value="">– Fehler beim Laden –</option>`;
        setStatus(err.message, "error");
      } finally {
        updateButtonState();
      }
    });

    formSelect.addEventListener("change", updateButtonState);
    idInput.addEventListener("input", updateButtonState);

    definitionBtn.addEventListener("click", async () => {
      const customer = customerSelect.value;
      const formPath = formSelect.value;
      if (!customer || !formPath) return;

      definitionBtn.disabled = true;
      setStatus("Lädt Formulardefinition...");

      try {
        const url = `/api/form/${encodeURIComponent(customer)}/${encodeURIComponent(formPath)}`;
        const res = await fetch(url);
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          throw new Error(body.error || `Fehler ${res.status}`);
        }
        const blob = await res.blob();
        const objectUrl = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = objectUrl;
        a.download = `${customer}_${formPath}.json`.replace(/[^a-zA-Z0-9._-]/g, "_");
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(objectUrl);
        setStatus("Formulardefinition heruntergeladen.", "success");
      } catch (err) {
        setStatus(err.message, "error");
      } finally {
        updateButtonState();
      }
    });

    downloadBtn.addEventListener("click", async () => {
      const customer = customerSelect.value;
      const formPath = formSelect.value;
      const submissionId = idInput.value.trim();
      if (!customer || !formPath || !submissionId) return;

      downloadBtn.disabled = true;
      setStatus("Lädt...");

      try {
        const url = `/api/submission/${encodeURIComponent(customer)}/${encodeURIComponent(formPath)}/${encodeURIComponent(submissionId)}`;
        const res = await fetch(url);
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          throw new Error(body.error || `Fehler ${res.status}`);
        }
        const blob = await res.blob();
        const objectUrl = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = objectUrl;
        a.download = `${customer}_${formPath}_${submissionId}.json`.replace(/[^a-zA-Z0-9._-]/g, "_");
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(objectUrl);
        setStatus("Submission heruntergeladen.", "success");
      } catch (err) {
        setStatus(err.message, "error");
      } finally {
        updateButtonState();
      }
    });
  }

  // ---- Stage-Konfiguration: Bereiche config und public aus forms/<env>/stage.json ----
  const escapeHtml = (v) =>
    String(v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  // Verschachtelte Objekte werden zu Zeilen wie "defaultValues.KassenName" aufgelöst
  function flattenConfig(obj, prefix = "") {
    return Object.entries(obj).flatMap(([key, value]) => {
      const name = prefix ? `${prefix}.${key}` : key;
      if (value && typeof value === "object" && !Array.isArray(value)) return flattenConfig(value, name);
      return [[name, value]];
    });
  }

  function configValueHtml(value) {
    if (value === "" || value === null || value === undefined) return `<span class="muted">–</span>`;
    if (typeof value === "string" && value.length > 120) {
      return `<details><summary>${value.length} Zeichen</summary><pre class="code">${escapeHtml(value)}</pre></details>`;
    }
    if (Array.isArray(value)) return escapeHtml(JSON.stringify(value));
    return escapeHtml(value);
  }

  function codeBlockHtml(text) {
    return text ? `<pre class="code">${escapeHtml(text)}</pre>` : `<p class="empty">Leer</p>`;
  }

  function renderStageBody(data) {
    const rows = flattenConfig(data.config)
      .map(([key, value]) => `<tr><td>${escapeHtml(key)}</td><td>${configValueHtml(value)}</td></tr>`)
      .join("");
    const custom = data.public.custom || {};
    const formModule = data.public.formModule || "";

    document.getElementById("stageBody").innerHTML = `
      <div class="panel">
        <h2>config</h2>
        <div class="table-scroll">
          <table class="kv">
            <thead><tr><th>Schlüssel</th><th>Wert</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>
      <div class="panel">
        <h2>public/custom</h2>
        <p class="label-small">CSS</p>
        ${codeBlockHtml(custom.css)}
        <p class="label-small">JavaScript</p>
        ${codeBlockHtml(custom.js)}
      </div>
      <div class="panel">
        <h2>public/formModule</h2>
        <details>
          <summary>${formModule.length} Zeichen anzeigen</summary>
          ${codeBlockHtml(formModule)}
        </details>
      </div>
    `;
  }

  async function renderStage() {
    contentEl.innerHTML = `<p class="empty">Lädt...</p>`;
    let envs;
    try {
      envs = await fetch("/api/stage-envs").then((r) => r.json());
    } catch {
      contentEl.innerHTML = `<p class="status-msg error">Stage-Liste konnte nicht geladen werden.</p>`;
      return;
    }
    if (envs.length === 0) {
      contentEl.innerHTML = `<p class="empty">Keine stage.json gefunden. Erzeuge sie mit "npm run export-stage -- --env=rps.dev".</p>`;
      return;
    }

    contentEl.innerHTML = `
      <div class="panel">
        <div class="field-row">
          <div class="field">
            <label for="stageEnv">Umgebung</label>
            <select id="stageEnv">
              ${envs.map((e) => `<option value="${escapeHtml(e)}">${escapeHtml(e)}</option>`).join("")}
            </select>
          </div>
          <button class="btn" id="stageRefresh">Von form.io aktualisieren</button>
        </div>
        <div id="stageStatus"></div>
      </div>
      <div id="stageBody"></div>
    `;

    const select = document.getElementById("stageEnv");
    const refreshBtn = document.getElementById("stageRefresh");
    const statusEl = document.getElementById("stageStatus");

    refreshBtn.addEventListener("click", async () => {
      refreshBtn.disabled = true;
      statusEl.className = "status-msg";
      statusEl.textContent = "Lädt aktuelle Stage-Konfiguration von form.io...";
      try {
        const res = await fetch(`/api/stage/${encodeURIComponent(select.value)}/refresh`, { method: "POST" });
        const body = await res.json();
        if (!res.ok) throw new Error(body.error || `Fehler ${res.status}`);
        statusEl.className = "status-msg success";
        statusEl.textContent = `Aktualisiert um ${new Date(body.updatedAt).toLocaleTimeString("de-DE")} (${body.redacted} Geheimnis(se) ersetzt).`;
        await show();
      } catch (err) {
        statusEl.className = "status-msg error";
        statusEl.textContent = err.message;
      } finally {
        refreshBtn.disabled = false;
      }
    });

    async function show() {
      document.getElementById("stageBody").innerHTML = `<p class="empty">Lädt...</p>`;
      const res = await fetch(`/api/stage/${encodeURIComponent(select.value)}`);
      const body = await res.json();
      if (!res.ok) {
        document.getElementById("stageBody").innerHTML = `<p class="status-msg error">${escapeHtml(body.error)}</p>`;
        return;
      }
      renderStageBody(body);
    }
    select.addEventListener("change", show);
    show();
  }

  // ---- Übersicht: Vergleich der Kunden pro Woche/Monat ----
  function renderOverview() {
    const field = periodField();
    const base = granularity === "week" ? summaryRows : monthlySummaryRows;
    const rows = applyRange(base, field, base);
    const weeks = Array.from(new Set(rows.map((r) => r[field]))).sort();
    const byCustomer = {};
    for (const row of rows) {
      byCustomer[row.customer] = byCustomer[row.customer] || {};
      byCustomer[row.customer][row[field]] = row.total;
    }

    const totals = {};
    for (const c of customers) {
      totals[c] = weeks.reduce((sum, w) => sum + (byCustomer[c]?.[w] || 0), 0);
    }
    const lastFetchByCustomer = Object.fromEntries(lastFetchRows.map((r) => [r.customer, r.fetched_at]));

    kpisEl.innerHTML = customers
      .map(
        (c, i) => `
      <div class="kpi">
        <div class="label">${label(c)} – Submissions im Zeitraum</div>
        <div class="value" style="color:${seriesColor(i)}">${totals[c].toLocaleString("de-DE")}</div>
      </div>`
      )
      .join("") +
      `<div class="kpi">
        <div class="label">Zuletzt aktualisiert</div>
        <div class="value small">${customers.map((c) => `${label(c)}: ${fmtDate(lastFetchByCustomer[c])}`).join("<br/>")}</div>
      </div>`;

    const periodLabel = granularity === "week" ? "Woche" : "Monat";
    contentEl.innerHTML = `
      <div class="panel">
        <h2>Submissions pro ${periodLabel} – Kundenvergleich</h2>
        <div class="chart-wrap"><canvas id="mainChart"></canvas></div>
      </div>
      <div class="panel">
        <details class="table-toggle" open>
          <summary>Tabellenansicht</summary>
          <div class="table-scroll">${buildOverviewTable(weeks, byCustomer)}</div>
        </details>
      </div>
      <div id="hostOverview"></div>
    `;

    const ctx = document.getElementById("mainChart");
    chartInstance = new Chart(ctx, {
      type: "line",
      data: {
        labels: weeks,
        datasets: customers.map((c, i) => ({
          label: label(c),
          data: weeks.map((w) => byCustomer[c]?.[w] || 0),
          borderColor: seriesColor(i),
          backgroundColor: seriesColor(i),
          pointRadius: 3,
          pointHoverRadius: 5,
          borderWidth: 2,
          tension: 0,
          fill: false,
        })),
      },
      options: chartOptions({ stacked: false }),
    });

    renderHostOverview();
  }

  async function renderHostOverview() {
    const target = document.getElementById("hostOverview");
    if (!target) return;
    const perCustomer = await Promise.all(
      customers.map((c) =>
        fetch(`/api/sources/${encodeURIComponent(c)}`)
          .then((r) => r.json())
          .then((rows) => rows.map((r) => ({ ...r, customer: c })))
      )
    );
    if (!document.getElementById("hostOverview")) return;

    const rows = applyRange(perCustomer.flat(), "month", monthlySummaryRows);
    const byHostCustomer = new Map();
    for (const r of rows) {
      const key = `${r.host}|${r.customer}`;
      const entry = byHostCustomer.get(key) || { host: r.host, customer: r.customer, forms: new Set(), count: 0 };
      entry.forms.add(r.form_title);
      entry.count += r.count;
      byHostCustomer.set(key, entry);
    }
    const list = Array.from(byHostCustomer.values()).sort(
      (a, b) => customers.indexOf(a.customer) - customers.indexOf(b.customer) || b.count - a.count
    );

    const body = list
      .map(
        (e) =>
          `<tr><td>${escapeHtml(e.host)}</td><td>${label(e.customer)}</td><td>${e.forms.size.toLocaleString("de-DE")}</td><td>${e.count.toLocaleString("de-DE")}</td></tr>`
      )
      .join("");

    if (list.length === 0) {
      target.innerHTML = `<div class="panel"><h2>Herkunft je Kunde</h2><p class="empty">Keine Herkunftsdaten im gewählten Zeitraum.</p></div>`;
      return;
    }

    const hostTotals = new Map();
    for (const e of list) hostTotals.set(e.host, (hostTotals.get(e.host) || 0) + e.count);
    const topHosts = Array.from(hostTotals.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15)
      .map(([host]) => host);

    target.innerHTML = `
      <div class="panel">
        <h2>Submissions je Domäne und Kunde (Top ${topHosts.length})</h2>
        <div class="host-chart-wrap" style="height:${topHosts.length * 30 + 90}px"><canvas id="hostChart"></canvas></div>
      </div>
      <div class="panel">
        <h2>Herkunft je Kunde</h2>
        <div class="table-scroll">
          <table>
            <thead><tr><th>Domäne</th><th>Kunde</th><th>Anzahl Formulare</th><th>Submissions</th></tr></thead>
            <tbody>${body}</tbody>
          </table>
        </div>
      </div>`;

    hostChartInstance = new Chart(document.getElementById("hostChart"), {
      type: "bar",
      data: {
        labels: topHosts,
        datasets: customers.map((c, i) => ({
          label: label(c),
          data: topHosts.map((host) => byHostCustomer.get(`${host}|${c}`)?.count || 0),
          backgroundColor: seriesColor(i),
          borderRadius: 4,
          stack: "hosts",
        })),
      },
      options: {
        ...chartOptions({ stacked: true }),
        indexAxis: "y",
      },
    });
  }

  function buildOverviewTable(weeks, byCustomer) {
    const head = `<tr><th>Kunde</th>${weeks.map((w) => `<th>${w}</th>`).join("")}<th>Gesamt</th></tr>`;
    const rows = customers
      .map((c) => {
        const cells = weeks.map((w) => `<td>${(byCustomer[c]?.[w] || 0).toLocaleString("de-DE")}</td>`).join("");
        const total = weeks.reduce((s, w) => s + (byCustomer[c]?.[w] || 0), 0);
        return `<tr><td>${label(c)}</td>${cells}<td><strong>${total.toLocaleString("de-DE")}</strong></td></tr>`;
      })
      .join("");
    return `<table><thead>${head}</thead><tbody>${rows}</tbody></table>`;
  }

  // ---- Kunden-Detailansicht: Top-Formulare pro Woche/Monat (gestapelt) ----
  async function renderCustomer(customer) {
    const field = periodField();
    const endpoint = granularity === "week" ? "stats" : "monthly";
    const rows = applyRange(
      await fetch(`/api/${endpoint}/${encodeURIComponent(customer)}`).then((r) => r.json()),
      field,
      granularity === "week" ? summaryRows : monthlySummaryRows
    );
    const weeks = Array.from(new Set(rows.map((r) => r[field]))).sort();

    const totalsByForm = {};
    for (const r of rows) {
      totalsByForm[r.form_title] = (totalsByForm[r.form_title] || 0) + r.count;
    }
    const allForms = Object.keys(totalsByForm);
    const nonZeroForms = allForms.filter((f) => totalsByForm[f] > 0);
    const topForms = nonZeroForms.sort((a, b) => totalsByForm[b] - totalsByForm[a]).slice(0, TOP_N_FORMS);
    const otherForms = nonZeroForms.filter((f) => !topForms.includes(f));

    const byFormWeek = {};
    for (const r of rows) {
      byFormWeek[r.form_title] = byFormWeek[r.form_title] || {};
      byFormWeek[r.form_title][r[field]] = r.count;
    }

    const grandTotal = nonZeroForms.reduce((s, f) => s + totalsByForm[f], 0);
    const lastFetch = lastFetchRows.find((r) => r.customer === customer)?.fetched_at;
    const topFormName = topForms[0] || "–";

    kpisEl.innerHTML = `
      <div class="kpi"><div class="label">Submissions im Zeitraum</div><div class="value">${grandTotal.toLocaleString("de-DE")}</div></div>
      <div class="kpi"><div class="label">Aktive Formulare</div><div class="value">${nonZeroForms.length}</div></div>
      <div class="kpi"><div class="label">Formulare gesamt</div><div class="value">${allForms.length}</div></div>
      <div class="kpi"><div class="label">Stärkstes Formular</div><div class="value small">${topFormName}</div></div>
      <div class="kpi"><div class="label">Zuletzt aktualisiert</div><div class="value small">${fmtDate(lastFetch)}</div></div>
    `;

    if (weeks.length === 0) {
      contentEl.innerHTML = `<p class="empty">Keine Daten für ${label(customer)}.</p>`;
      return;
    }

    const periodLabel = granularity === "week" ? "Woche" : "Monat";
    contentEl.innerHTML = `
      <div class="panel">
        <h2>${label(customer)} – Submissions pro ${periodLabel} (Top ${TOP_N_FORMS} Formulare)</h2>
        <div class="chart-wrap"><canvas id="mainChart"></canvas></div>
      </div>
      <div class="panel">
        <details class="table-toggle">
          <summary>Tabellenansicht (alle Formulare, inkl. 0 Submissions)</summary>
          <div class="table-scroll">${buildCustomerTable(weeks, allForms, byFormWeek, totalsByForm)}</div>
        </details>
      </div>
      <div id="activityPanels"></div>
    `;

    const datasets = topForms.map((f, i) => ({
      label: f,
      data: weeks.map((w) => byFormWeek[f]?.[w] || 0),
      backgroundColor: seriesColor(i),
      borderRadius: 4,
      borderSkipped: false,
      stack: "stack1",
    }));
    if (otherForms.length > 0) {
      datasets.push({
        label: `Sonstige (${otherForms.length})`,
        data: weeks.map((w) => otherForms.reduce((s, f) => s + (byFormWeek[f]?.[w] || 0), 0)),
        backgroundColor: otherColor,
        borderRadius: 4,
        borderSkipped: false,
        stack: "stack1",
      });
    }

    const ctx = document.getElementById("mainChart");
    chartInstance = new Chart(ctx, {
      type: "bar",
      data: { labels: weeks, datasets },
      options: chartOptions({ stacked: true }),
    });

    await renderActivity(customer);
  }

  // ---- Wochentag/Stunde und Herkunft (Monatsbasis, gleicher Zeitraumfilter) ----
  const WEEKDAY_NAMES = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];

  async function renderActivity(customer) {
    const target = document.getElementById("activityPanels");
    if (!target) return;
    const [heat, sources] = await Promise.all([
      fetch(`/api/heatmap/${encodeURIComponent(customer)}`).then((r) => r.json()),
      fetch(`/api/sources/${encodeURIComponent(customer)}`).then((r) => r.json()),
    ]);
    if (!document.getElementById("activityPanels")) return;

    const heatRows = applyRange(heat, "month", monthlySummaryRows);
    const sourceRows = applyRange(sources, "month", monthlySummaryRows);
    target.innerHTML = heatmapPanelHtml(heatRows) + sourcesPanelHtml(sourceRows);
  }

  function heatmapPanelHtml(rows) {
    const grid = Array.from({ length: 7 }, () => Array(24).fill(0));
    for (const r of rows) grid[r.weekday][r.hour] += r.count;
    const max = Math.max(0, ...grid.flat());
    const hhmm = (h) => `${String(h).padStart(2, "0")}:00`;

    const head = `<div></div>${Array.from({ length: 24 }, (_, h) => `<div class="hm-head">${h}</div>`).join("")}`;
    const body = grid
      .map((hours, d) => {
        const cells = hours
          .map((count, h) => {
            const pct = max ? Math.round((count / max) * 100) : 0;
            return `<div class="hm-cell" style="background:color-mix(in srgb, var(--series-1) ${pct}%, var(--gridline))" title="${WEEKDAY_NAMES[d]} ${hhmm(h)} – ${count} Submission(s)"></div>`;
          })
          .join("");
        return `<div class="hm-day">${WEEKDAY_NAMES[d]}</div>${cells}`;
      })
      .join("");

    const slots = grid.flatMap((hours, d) => hours.map((count, h) => ({ d, h, count })));
    const byCount = slots.slice().sort((a, b) => b.count - a.count || a.d - b.d || a.h - b.h);
    const describe = (s) => `<strong>${WEEKDAY_NAMES[s.d]} ${hhmm(s.h)}</strong> (${s.count})`;
    const insights =
      max === 0
        ? `<p class="empty">Keine Submissions im gewählten Zeitraum.</p>`
        : `<div class="insights">
            <div>Meistgenutzt: ${byCount.slice(0, 3).map(describe).join(", ")}</div>
            <div>Am wenigsten genutzt: ${byCount.slice(-3).reverse().map(describe).join(", ")}</div>
          </div>`;

    return `
      <div class="panel">
        <h2>Submissions nach Wochentag und Uhrzeit (Berliner Zeit)</h2>
        <div class="table-scroll"><div class="heatmap">${head}${body}</div></div>
        ${insights}
      </div>`;
  }

  function sourcesPanelHtml(rows) {
    const total = rows.reduce((s, r) => s + r.count, 0);
    const aggregate = (keyOf) => {
      const map = new Map();
      for (const r of rows) {
        const key = keyOf(r);
        const entry = map.get(key) || { ...r, count: 0 };
        entry.count += r.count;
        map.set(key, entry);
      }
      return Array.from(map.values()).sort((a, b) => b.count - a.count);
    };
    const byHost = aggregate((r) => r.host);
    const byHostForm = aggregate((r) => `${r.host}|${r.form_title}`).slice(0, 30);
    const share = (n) => (total ? `${((n / total) * 100).toFixed(1).replace(".", ",")} %` : "–");

    if (total === 0) {
      return `<div class="panel"><h2>Herkunft der Submissions</h2><p class="empty">Keine Herkunftsdaten im gewählten Zeitraum.</p></div>`;
    }

    const body = byHostForm
      .map(
        (r) =>
          `<tr><td>${escapeHtml(r.host)}</td><td>${escapeHtml(r.form_title)}</td><td>${r.count.toLocaleString("de-DE")}</td><td>${share(r.count)}</td></tr>`
      )
      .join("");

    return `
      <div class="panel">
        <h2>Herkunft der Submissions (Host und Formular)</h2>
        <div class="insights">Stärkster Host: <strong>${escapeHtml(byHost[0].host)}</strong> (${share(byHost[0].count)})</div>
        <div class="table-scroll">
          <table>
            <thead><tr><th>Host</th><th>Formular</th><th>Submissions</th><th>Anteil</th></tr></thead>
            <tbody>${body}</tbody>
          </table>
        </div>
      </div>`;
  }

  function buildCustomerTable(weeks, forms, byFormWeek, totalsByForm) {
    const sorted = forms.slice().sort((a, b) => totalsByForm[b] - totalsByForm[a]);
    const head = `<tr><th>Formular</th>${weeks.map((w) => `<th>${w}</th>`).join("")}<th>Gesamt</th></tr>`;
    const body = sorted
      .map((f) => {
        const cells = weeks.map((w) => `<td>${(byFormWeek[f]?.[w] || 0).toLocaleString("de-DE")}</td>`).join("");
        return `<tr><td>${f}</td>${cells}<td><strong>${totalsByForm[f].toLocaleString("de-DE")}</strong></td></tr>`;
      })
      .join("");
    return `<table><thead>${head}</thead><tbody>${body}</tbody></table>`;
  }

  function chartOptions({ stacked }) {
    return {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: "index", intersect: false },
      plugins: {
        legend: { position: "bottom", labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true } },
        tooltip: { backgroundColor: surface1, titleColor: color("--text-primary"), bodyColor: textSecondary, borderColor: gridline, borderWidth: 1 },
      },
      scales: {
        x: { stacked, grid: { display: false }, border: { color: gridline } },
        y: { stacked, beginAtZero: true, grid: { color: gridline }, border: { display: false } },
      },
    };
  }

  loadAll();
})();
