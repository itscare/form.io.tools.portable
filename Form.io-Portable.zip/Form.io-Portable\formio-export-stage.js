/**
 * form.io – Stage-Konfiguration (Global-Settings) exportieren
 * ---------------------------------------------------------------------
 * Liest das Projekt-Dokument einer Umgebung und speichert es als
 *   <out>/<env>/stage.json
 *
 * Enthalten sind u.a. settings (Global-Settings: E-Mail, Storage, OAuth, ...),
 * config (Frontend-URLs, Standardwerte) und formModule.
 *
 * Geheimnisse (Passwörter, API-Keys, Client-Secrets, Verbindungsdaten) werden
 * durch "<redacted>" ersetzt, damit die Datei committet werden kann. Die Struktur
 * bleibt erhalten, damit Änderungen im Git-Diff sichtbar sind.
 * Zähler ohne Aussagekraft (apiCalls, created, modified, owner) werden weggelassen.
 *
 * Nutzung:
 *   node formio-export-stage.js --env=rps.dev
 *     -> schreibt ./forms/rps.dev/stage.json
 *
 *   node formio-export-stage.js --env=rps.dev --out=../rps-konfiguration
 *
 * Parameter:
 *   --env=<name>   Pflicht, lädt ".env.<name>"
 *   --out=<dir>    Basisordner (Standard: "./forms")
 * ---------------------------------------------------------------------
 */
const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");

const { buildConfigFromEnvObject, createClient } = require("./lib/formio-client");

const STAGE_FILE = "stage.json";
const REDACTED = "<redacted>";
// Name eines Blattwerts, der ein Geheimnis enthalten kann (case-insensitive)
const SECRET_KEY = /key|secret|pass|token|credential|clientid|cskey|refresh|apikey|bind|user|connectionstring/i;
// Top-Level-Felder ohne Aussagekraft für die Konfiguration
const DROP_TOP_LEVEL = ["apiCalls", "created", "modified", "owner"];

function argValue(name) {
  const arg = process.argv.find((a) => a.startsWith(`--${name}=`));
  return arg ? arg.slice(name.length + 3) : null;
}

/**
 * Ersetzt Geheimnisse rekursiv durch REDACTED. Leere Werte, Booleans und null bleiben
 * erhalten, weil sie kein Geheimnis preisgeben. Zählt die Ersetzungen in counter.redacted.
 */
function sanitizeStage(project, counter = { redacted: 0 }) {
  const walk = (value, keyName) => {
    if (Array.isArray(value)) return value.map((v) => walk(v, keyName));
    if (value && typeof value === "object") {
      const out = {};
      for (const [k, v] of Object.entries(value)) out[k] = walk(v, k);
      return out;
    }
    const isEmpty = value === "" || value === null || value === undefined;
    const isBoolean = typeof value === "boolean";
    if (keyName && SECRET_KEY.test(keyName) && !isEmpty && !isBoolean) {
      counter.redacted++;
      return REDACTED;
    }
    return value;
  };

  const withoutCounters = Object.fromEntries(
    Object.entries(project).filter(([k]) => !DROP_TOP_LEVEL.includes(k))
  );
  return { data: walk(withoutCounters, ""), redacted: counter.redacted };
}

function loadEnvConfig(envName) {
  const envFile = `.env.${envName}`;
  const envPath = path.resolve(__dirname, envFile);
  if (!fs.existsSync(envPath)) {
    throw new Error(`Konfigurationsdatei "${envFile}" nicht gefunden.`);
  }
  const parsed = dotenv.parse(fs.readFileSync(envPath, "utf-8"));
  return buildConfigFromEnvObject(parsed, { customer: envName.split(".")[0], envFile });
}

async function main() {
  const envName = argValue("env");
  if (!envName) throw new Error("Bitte --env=<name> angeben, z.B. --env=rps.dev.");
  const outDir = argValue("out") || "./forms";

  const client = createClient(loadEnvConfig(envName));
  const project = await client.getProject();
  const { data, redacted } = sanitizeStage(project);

  const targetDir = path.resolve(__dirname, outDir, envName);
  fs.mkdirSync(targetDir, { recursive: true });
  const filePath = path.join(targetDir, STAGE_FILE);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2) + "\n", "utf-8");

  console.log(`✔ Stage-Konfiguration gespeichert: ${filePath}`);
  console.log(`✔ ${redacted} Geheimnis(se) durch "${REDACTED}" ersetzt.`);
}

module.exports = { sanitizeStage, STAGE_FILE };

if (require.main === module) {
  main().catch((err) => {
    console.error("Fehler:", err.message);
    process.exit(1);
  });
}
