/**
 * Aktualisiert die Wochen-/Monatsstatistik monatsweise für ein Jahr.
 * Startet formio-weekly-stats.js nacheinander für jeden Monat, jeweils mit
 * FORMIO_DATE_FROM/FORMIO_DATE_TO auf den Monat gesetzt. Bricht beim ersten Fehler ab.
 *
 * Nutzung:
 *   npm run update-year -- --env=rps.prod
 *   npm run update-year -- --env=rps.prod,he.prod,bw.prod --year=2026
 *
 * Ohne --year wird das aktuelle Jahr verwendet, bis zum aktuellen Monat.
 */
const { spawnSync } = require("child_process");
const path = require("path");

const args = Object.fromEntries(
  process.argv.slice(2).map((arg) => {
    const [key, ...rest] = arg.replace(/^--/, "").split("=");
    return [key, rest.join("=") || true];
  })
);

if (!args.env || args.env === true) {
  console.error("Fehler: --env=<name> fehlt, z.B. --env=rps.prod (mehrere mit Komma).");
  process.exit(1);
}

const now = new Date();
const year = args.year ? Number(args.year) : now.getFullYear();
const lastMonth = year === now.getFullYear() ? now.getMonth() + 1 : 12;

/** Erster und letzter Tag eines Monats als "YYYY-MM-DD" */
function monthRange(y, m) {
  const pad = (n) => String(n).padStart(2, "0");
  const lastDay = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return { from: `${y}-${pad(m)}-01`, to: `${y}-${pad(m)}-${pad(lastDay)}` };
}

const envNames = String(args.env).split(",").map((s) => s.trim()).filter(Boolean);

for (const envName of envNames) {
  for (let month = 1; month <= lastMonth; month++) {
    const { from, to } = monthRange(year, month);
    console.log(`\n=== ${envName}: ${from} bis ${to} ===`);

    const result = spawnSync(process.execPath, [path.join(__dirname, "formio-weekly-stats.js"), `--env=${envName}`], {
      stdio: "inherit",
      env: { ...process.env, FORMIO_DATE_FROM: from, FORMIO_DATE_TO: to },
    });

    if (result.status !== 0) {
      console.error(`\nAbbruch: ${envName} ${from} bis ${to} ist fehlgeschlagen (Exit ${result.status}).`);
      process.exit(result.status || 1);
    }
  }
}

console.log(`\nFertig: ${envNames.join(", ")} für ${year} (Januar bis ${lastMonth}) aktualisiert.`);
