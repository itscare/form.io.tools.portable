/**
 * form.io – Formulare aus einem Git-Export in eine andere Umgebung übernehmen
 * ---------------------------------------------------------------------
 * Quelle der Formulardefinitionen ist der Git-Ordner, den formio-export-forms.js
 * erzeugt (Standard: ./forms/<from>). Was dort committet ist, wird eingespielt.
 *
 * Übernommen werden je ausgewähltem Formular:
 *   - die Definition (Felder, Layout, Einstellungen). Bestehende Formulare werden
 *     per PUT auf ihrer ID aktualisiert, neue per POST angelegt. Dadurch bleiben
 *     die Submissions der Zielumgebung erhalten.
 *   - die Rollen-Zugriffsrechte (access, submissionAccess): Rollen werden über
 *     machineName, sonst über den Titel zugeordnet; fehlende Rollen werden angelegt
 *   - die Aktionen/Webhooks aus <path>.actions.json (Zuordnung über Titel + name)
 *
 * URL-Umstellung:
 *   Verweise auf den Ursprung der Quelle (FORMIO_BASE_URL, z.B. https://dev-host)
 *   werden in Definition und Aktionen durch den Ursprung von FORMIO_WEBHOOK_BASE_URL
 *   der Zielumgebung ersetzt (z.B. https://prod-host). Ist die Variable im Ziel nicht
 *   gesetzt, bleiben die URLs unverändert und der Plan warnt.
 *
 * Submissions werden NICHT übertragen.
 *
 * Sicherheit:
 *   - Ohne --yes wird vor dem Schreiben nachgefragt ("ja" eingeben).
 *   - Vor dem Schreiben wird der Zielstand der überschriebenen Formulare nach
 *     backups/<to>/<zeitstempel>/ gesichert.
 *   - Es wird nichts gelöscht. Prod-only-Aktionen und -Formulare bleiben bestehen.
 *
 * Nutzung:
 *   node formio-promote-forms.js --from=rps.dev --to=rps.prod --dry-run
 *     -> interaktive Auswahl, zeigt den Plan, schreibt nichts
 *
 *   node formio-promote-forms.js --from=rps.dev --to=rps.prod --form=antrag,kontakt
 *     -> nur diese Formulare, mit Bestätigung vor dem Schreiben
 *
 * Parameter:
 *   --from=<env>        Quellumgebung (z.B. rps.dev), Standard-Ordner ./forms/<env>
 *   --to=<env>          Zielumgebung (z.B. rps.prod)
 *   --dir=<ordner>      Git-Ordner mit dem Export (Standard: ./forms/<from>)
 *   --form=<pfad>[,..]  Formulare auswählen (sonst interaktive Auswahl)
 *   --dry-run           nur Plan anzeigen
 *   --yes               ohne Rückfrage schreiben
 * ---------------------------------------------------------------------
 */
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const dotenv = require("dotenv");

const { buildConfigFromEnvObject, createClient } = require("./lib/formio-client");

const ROLES_FILE = "roles.json";
// Felder, die die Zielumgebung selbst vergibt oder die nicht übertragen werden sollen
const VOLATILE_FORM_KEYS = [
  "_id", "project", "owner", "created", "modified", "_vid",
  "revisions", "submissionRevisions", "machineName",
];
const VOLATILE_ACTION_KEYS = ["_id", "form", "owner", "created", "modified", "machineName"];

function argValue(name) {
  const arg = process.argv.find((a) => a.startsWith(`--${name}=`));
  return arg ? arg.slice(name.length + 3) : null;
}

function hasFlag(name) {
  return process.argv.includes(`--${name}`);
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf-8"));
}

function readOptionalJson(filePath) {
  return fs.existsSync(filePath) ? readJson(filePath) : [];
}

function writeJson(filePath, data) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2) + "\n", "utf-8");
}

function ask(rl, question) {
  return new Promise((resolve) => rl.question(question, resolve));
}

/**
 * Lädt die Konfiguration einer Umgebung (.env.<name>), wie formio-export-forms.js.
 * Zusätzlich wird FORMIO_WEBHOOK_BASE_URL gelesen (Basis für Webhook-URLs dieser Umgebung).
 */
function loadEnvConfig(envName) {
  const envFile = `.env.${envName}`;
  const envPath = path.resolve(__dirname, envFile);
  if (!fs.existsSync(envPath)) {
    throw new Error(`Konfigurationsdatei "${envFile}" nicht gefunden.`);
  }
  const parsed = dotenv.parse(fs.readFileSync(envPath, "utf-8"));
  return {
    ...buildConfigFromEnvObject(parsed, { customer: envName.split(".")[0], envFile }),
    webhookBaseUrl: parsed.FORMIO_WEBHOOK_BASE_URL || "",
  };
}

/** Alle Formulare aus dem Git-Ordner, mit ihren Aktionen. */
function loadSourceForms(dir) {
  return fs
    .readdirSync(dir)
    .filter((f) => f.endsWith(".json") && f !== ROLES_FILE && f !== "stage.json" && !f.endsWith(".actions.json"))
    .map((file) => {
      const definition = readJson(path.join(dir, file));
      const actions = readOptionalJson(path.join(dir, file.replace(/\.json$/, ".actions.json")));
      return { path: definition.path, title: definition.title, definition, actions };
    })
    .sort((a, b) => a.title.localeCompare(b.title, "de"));
}

/** Alle Rollen-IDs, die in den Zugriffsrechten eines Formulars vorkommen. */
function collectRoleIds(definition) {
  return [...(definition.access || []), ...(definition.submissionAccess || [])].flatMap((e) => e.roles || []);
}

/**
 * Ordnet jede verwendete Quell-Rolle einer Ziel-Rolle zu: zuerst über machineName,
 * dann über den Titel. Ergebnis ist null für Rollen, die im Ziel fehlen.
 */
function resolveRoles(sourceRoles, targetRoles, usedIds) {
  const map = new Map();
  for (const id of usedIds) {
    const src = sourceRoles.find((r) => r._id === id);
    if (!src) {
      throw new Error(`Rolle ${id} steht nicht in ${ROLES_FILE} – bitte die Quelle neu exportieren.`);
    }
    const match =
      (src.machineName && targetRoles.find((r) => r.machineName === src.machineName)) ||
      targetRoles.find((r) => r.title === src.title);
    map.set(id, match ? match._id : null);
  }
  return map;
}

/**
 * Ersetzt in allen Strings den Ursprung der Quelle durch den Ursprung des Ziels.
 * Ohne Ziel-Ursprung (FORMIO_WEBHOOK_BASE_URL nicht gesetzt) bleibt alles unverändert.
 */
function replaceOrigin(value, origins) {
  if (!origins.from || !origins.to || origins.from === origins.to) return value;
  if (typeof value === "string") return value.split(origins.from).join(origins.to);
  if (Array.isArray(value)) return value.map((v) => replaceOrigin(v, origins));
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, replaceOrigin(v, origins)]));
  }
  return value;
}

/** Anzahl der Vorkommen des Quell-Ursprungs in einem Objekt (für den Plan). */
function countOrigin(value, origins) {
  if (!origins.from) return 0;
  return JSON.stringify(value).split(origins.from).length - 1;
}

/** Entfernt umgebungsspezifische Felder, ersetzt Rollen-IDs und URLs. */
function transformDefinition(definition, roleMap, origins) {
  const result = {};
  for (const [key, value] of Object.entries(definition)) {
    if (!VOLATILE_FORM_KEYS.includes(key)) result[key] = value;
  }
  for (const key of ["access", "submissionAccess"]) {
    if (!result[key]) continue;
    result[key] = result[key].map((entry) => ({
      ...entry,
      roles: (entry.roles || []).map((id) => {
        const target = roleMap.get(id);
        if (!target) throw new Error(`Rolle ${id} hat keine Entsprechung im Ziel.`);
        return target;
      }),
    }));
  }
  return replaceOrigin(result, origins);
}

function transformAction(action, origins) {
  const result = {};
  for (const [key, value] of Object.entries(action)) {
    if (!VOLATILE_ACTION_KEYS.includes(key)) result[key] = value;
  }
  return replaceOrigin(result, origins);
}

/** Interaktive Auswahl der Formulare über Nummern. */
async function chooseForms(sourceForms) {
  console.log("\nVerfügbare Formulare:");
  sourceForms.forEach((f, i) => console.log(`  [${i + 1}] ${f.title}  (${f.path})`));

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = (await ask(rl, "\nFormulare wählen (Nummern kommagetrennt, 'alle' für alle): ")).trim();
    if (answer.toLowerCase() === "alle") return sourceForms;
    const indexes = answer.split(",").map((s) => Number(s.trim()) - 1);
    if (indexes.length === 0 || indexes.some((i) => !Number.isInteger(i) || i < 0 || i >= sourceForms.length)) {
      throw new Error("Ungültige Auswahl.");
    }
    return [...new Set(indexes)].map((i) => sourceForms[i]);
  } finally {
    rl.close();
  }
}

async function confirmWrite(targetEnv) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await ask(rl, `\nJetzt in "${targetEnv}" schreiben? Zum Bestätigen "ja" eingeben: `);
    return answer.trim().toLowerCase() === "ja";
  } finally {
    rl.close();
  }
}

/** Sichert den Zielstand der Formulare, die überschrieben werden. */
async function backupTarget(targetClient, targetEnv, existingForms, targetRoles) {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const dir = path.resolve(__dirname, "backups", targetEnv, stamp);
  for (const form of existingForms) {
    const definition = await targetClient.getFormDefinition(form.path);
    const actions = await targetClient.getActions(form.path);
    writeJson(path.join(dir, `${form.path}.json`), definition);
    writeJson(path.join(dir, `${form.path}.actions.json`), actions);
  }
  writeJson(path.join(dir, ROLES_FILE), targetRoles);
  return dir;
}

async function main() {
  const fromEnv = argValue("from");
  const toEnv = argValue("to");
  if (!fromEnv || !toEnv) throw new Error("Bitte --from=<env> und --to=<env> angeben.");
  if (fromEnv === toEnv) throw new Error("Quelle und Ziel dürfen nicht gleich sein.");

  const dir = path.resolve(__dirname, argValue("dir") || path.join("forms", fromEnv));
  const dryRun = hasFlag("dry-run");

  if (!fs.existsSync(dir)) {
    throw new Error(`Git-Ordner "${dir}" nicht gefunden. Bitte zuerst mit formio-export-forms.js exportieren.`);
  }
  const sourceForms = loadSourceForms(dir);
  if (sourceForms.length === 0) throw new Error(`Keine Formulare in "${dir}".`);
  const sourceRoles = readJson(path.join(dir, ROLES_FILE));

  let selected;
  const wanted = argValue("form");
  if (wanted) {
    const paths = wanted.split(",").map((s) => s.trim()).filter(Boolean);
    const missing = paths.filter((p) => !sourceForms.some((f) => f.path === p));
    if (missing.length > 0) throw new Error(`Nicht im Export gefunden: ${missing.join(", ")}`);
    selected = sourceForms.filter((f) => paths.includes(f.path));
  } else {
    selected = await chooseForms(sourceForms);
  }

  const sourceConfig = loadEnvConfig(fromEnv);
  const targetConfig = loadEnvConfig(toEnv);
  const sourceClient = createClient(sourceConfig);
  const targetClient = createClient(targetConfig);
  const origins = {
    from: new URL(sourceConfig.baseUrl).origin,
    to: targetConfig.webhookBaseUrl ? new URL(targetConfig.webhookBaseUrl).origin : "",
  };

  const targetRoles = await targetClient.getRoles();
  const targetFormsByPath = new Map((await targetClient.listAllForms()).map((f) => [f.path, f]));

  const usedRoleIds = [...new Set(selected.flatMap((f) => collectRoleIds(f.definition)))];
  const roleMap = resolveRoles(sourceRoles, targetRoles, usedRoleIds);
  const missingRoles = usedRoleIds.filter((id) => roleMap.get(id) === null);

  // Plan erstellen (nur Lesezugriffe)
  const plan = selected.map((form) => ({
    form,
    existing: targetFormsByPath.get(form.path),
    urlHits: countOrigin(form.definition, origins) + countOrigin(form.actions, origins),
  }));

  console.log(`\nPlan: ${fromEnv} → ${toEnv}`);
  for (const entry of plan) {
    const action = entry.existing ? "aktualisieren (Submissions bleiben erhalten)" : "anlegen";
    console.log(`  • ${entry.form.title} (${entry.form.path}): ${action}, ${entry.form.actions.length} Aktion(en)`);
    if (entry.urlHits > 0 && origins.to) {
      console.log(`    URLs: ${entry.urlHits} Verweis(e) von ${origins.from} auf ${origins.to} umgestellt`);
    } else if (entry.urlHits > 0) {
      console.log(`    ⚠ ${entry.urlHits} Verweis(e) auf ${origins.from} bleiben unverändert: FORMIO_WEBHOOK_BASE_URL in "${toEnv}" fehlt.`);
    }
  }
  if (usedRoleIds.length > 0) {
    console.log(`  Rollen: ${usedRoleIds.length - missingRoles.length} zugeordnet, ${missingRoles.length} fehlen im Ziel`);
    for (const id of missingRoles) {
      const src = sourceRoles.find((r) => r._id === id);
      console.log(`    + wird angelegt: ${src ? src.title : id}`);
    }
  }

  if (dryRun) {
    console.log("\nTrockenlauf: Es wurde nichts geschrieben.");
    return;
  }
  if (!hasFlag("yes") && !(await confirmWrite(toEnv))) {
    console.log("Abgebrochen. Es wurde nichts geschrieben.");
    return;
  }

  const backupDir = await backupTarget(
    targetClient,
    toEnv,
    plan.filter((p) => p.existing).map((p) => p.existing),
    targetRoles
  );
  console.log(`✔ Zielstand gesichert in: ${backupDir}`);

  // 1. Fehlende Rollen anlegen
  for (const id of missingRoles) {
    const src = sourceRoles.find((r) => r._id === id);
    const created = await targetClient.createRole(src.title);
    roleMap.set(id, created._id);
    console.log(`✔ Rolle angelegt: ${src.title}`);
  }

  for (const { form, existing } of plan) {
    // 2. Formular anlegen oder aktualisieren. Bei PUT bleibt die ID und damit die Submissions erhalten.
    const transformed = transformDefinition(form.definition, roleMap, origins);
    if (existing) {
      await targetClient.updateForm(existing._id, { ...transformed, _id: existing._id });
      console.log(`✔ Formular aktualisiert: ${form.title}`);
    } else {
      await targetClient.createForm(transformed);
      console.log(`✔ Formular angelegt: ${form.title}`);
    }

    // 3. Aktionen (Webhooks) übernehmen; vorhandene mit gleichem Titel und name werden aktualisiert
    const targetActions = existing ? await targetClient.getActions(form.path) : [];
    for (const action of form.actions) {
      const clean = transformAction(action, origins);
      const match = targetActions.find((t) => t.title === action.title && t.name === action.name);
      if (match) {
        await targetClient.updateAction(form.path, match._id, clean);
      } else {
        await targetClient.createAction(form.path, clean);
      }
    }
    if (form.actions.length > 0) console.log(`  ✔ ${form.actions.length} Aktion(en) übernommen`);
  }

  console.log(`\nFertig. Sicherung des vorherigen Stands: ${backupDir}`);
}

module.exports = {
  main,
  transformDefinition,
  transformAction,
  replaceOrigin,
  resolveRoles,
  collectRoleIds,
  loadSourceForms,
};

if (require.main === module) {
  main().catch((err) => {
    console.error("Fehler:", err.message);
    process.exit(1);
  });
}
