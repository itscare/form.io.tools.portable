/**
 * form.io – Statistik: Abgegebene Submissions pro Woche und Formular
 * ---------------------------------------------------------------------
 * Voraussetzungen: Node.js 18+ (nutzt das eingebaute fetch)
 *
 * Nutzung:
 *   1. Konfiguration unten unter CONFIG anpassen.
 *   2. Ausführen:  node formio-weekly-stats.js
 *   3. Ergebnis:
 *        - Konsolen-Ausgabe als Tabelle
 *        - CSV-Datei (Standard: "Reports/formio-weekly-stats-<kunde>.csv",
 *          konfigurierbar über FORMIO_CSV_OUTPUT_PATH)
 *
 * Authentifizierung:
 *   Option A) API-Key (empfohlen, falls vorhanden):
 *        FORMIO_API_KEY setzen -> wird als "x-token" Header gesendet
 *   Option B) Login mit E-Mail/Passwort (z.B. Projekt-Admin-Login):
 *        FORMIO_EMAIL und FORMIO_PASSWORD setzen, FORMIO_API_KEY leer lassen
 *
 * Konfiguration erfolgt über eine .env-Datei im selben Ordner (siehe .env.example).
 * Benötigte Pakete:  npm install dotenv undici
 *
 * Mehrere Umgebungen (z.B. Staging/Produktion):
 *   Lege zusätzlich z.B. ".env.staging" oder ".env.production" an und rufe auf mit:
 *     node formio-weekly-stats.js --env=staging
 *     node formio-weekly-stats.js --env=production
 *   Ohne "--env=" Parameter wird die normale ".env" geladen.
 *
 * Retry-Verhalten:
 *   Bei vorübergehenden Serverfehlern (429/502/503/504) oder Netzwerkfehlern
 *   wird automatisch mit exponentiellem Backoff erneut versucht.
 *   Konfigurierbar über FORMIO_MAX_RETRIES (Standard: 5) und
 *   FORMIO_RETRY_BASE_DELAY_MS (Standard: 1000ms, verdoppelt sich pro Versuch).
 * Zeitraum:
 *   FORMIO_DATE_FROM/FORMIO_DATE_TO in der .env eingrenzen möglich.
 *   Werden BEIDE leer gelassen, wird automatisch der aktuelle Kalendermonat
 *   ausgewertet. Für "alle Submissions" explizit ein weites Datum setzen,
 *   z.B. FORMIO_DATE_FROM=2000-01-01.
 *
 * Performance-Hinweis:
 *   Beim Laden der Submissions wird per "select=created" nur das Datumsfeld
 *   angefragt, nicht die komplette Formular-Nutzlast. Das reduziert die
 *   Antwortgröße und damit Ladezeiten/Timeout-Risiko spürbar, besonders bei
 *   Formularen mit vielen Feldern oder großen Anhängen.
 *
 * Formulare ausschließen:
 *   Mit FORMIO_EXCLUDE_NAME_CONTAINS kannst du Formulare überspringen, deren
 *   Titel/Name/Pfad einen bestimmten Text enthält (kommagetrennt, mehrere möglich),
 *   z.B. "_WARTUNG,_TEST" schließt alle Formulare mit "_WARTUNG" oder "_TEST" im
 *   Namen aus. Groß-/Kleinschreibung wird ignoriert.
 *
 * Firmen-Proxy/VPN:
 *   Falls du hinter einem Firmen-Proxy sitzt (Fehler UND_ERR_CONNECT_TIMEOUT),
 *   setze FORMIO_PROXY_URL in der .env, z.B. "http://proxy.firma.de:8080".
 *   Alternativ werden auch die Standard-Variablen HTTPS_PROXY/HTTP_PROXY erkannt.
 *   Mit FORMIO_NO_PROXY (oder NO_PROXY) kannst du einzelne Hosts vom Proxy
 *   ausnehmen, z.B. "formio.internal.firma.de,.internal.firma.de".
 * ---------------------------------------------------------------------
 */

/**
 * Lädt die passende .env-Datei.
 * Standard: ".env"
 * Mit Parameter "--env=<name>" wird stattdessen ".env.<name>" geladen,
 * z.B. "node formio-weekly-stats.js --env=staging" -> lädt ".env.staging"
 */
const path = require("path");
const envArg = process.argv.find((arg) => arg.startsWith("--env="));
const envName = envArg ? envArg.split("=")[1] : null;
const envFile = envName ? `.env.${envName}` : ".env";
const envPath = path.resolve(__dirname, envFile);

const dotenvResult = require("dotenv").config({ path: envPath });
if (dotenvResult.error) {
  console.error(`Fehler: Konnte "${envFile}" nicht laden (${envPath}).`);
  console.error(dotenvResult.error.message);
  process.exit(1);
}
console.log(`✔ Konfiguration geladen aus: ${envFile}`);

// Kunde für die Datenbank (z.B. "rps", "he", "bw"), abgeleitet aus "--env=<kunde>.prod".
// Kann über FORMIO_CUSTOMER in der .env überschrieben werden.
const CUSTOMER =
  process.env.FORMIO_CUSTOMER || (envName ? envName.split(".")[0] : "default");

const { upsertWeeklyStats, upsertMonthlyStats, replaceActivityStats } = require("./lib/db");

const { ProxyAgent } = require("undici");

// Falls ein Firmen-Proxy konfiguriert ist, wird er nur für Hosts genutzt,
// die NICHT in der NO_PROXY-Liste stehen (analog zur Standard-NO_PROXY-Variable).
const proxyUrl =
  process.env.FORMIO_PROXY_URL ||
  process.env.HTTPS_PROXY ||
  process.env.https_proxy ||
  process.env.HTTP_PROXY ||
  process.env.http_proxy;

const noProxyList = (
  process.env.FORMIO_NO_PROXY ||
  process.env.NO_PROXY ||
  process.env.no_proxy ||
  ""
)
  .split(",")
  .map((entry) => entry.trim().toLowerCase())
  .filter(Boolean);

const proxyAgent = proxyUrl ? new ProxyAgent(proxyUrl) : null;

if (proxyUrl) {
  console.log(`✔ Proxy konfiguriert: ${proxyUrl}`);
  if (noProxyList.length > 0) {
    console.log(`✔ Proxy-Ausnahmen (NO_PROXY): ${noProxyList.join(", ")}`);
  }
}

/** Prüft, ob ein Hostname von der Proxy-Nutzung ausgenommen ist */
function isBypassed(hostname) {
  const host = hostname.toLowerCase();
  return noProxyList.some((entry) => {
    if (entry === "*") return true;
    if (entry.startsWith(".")) return host.endsWith(entry) || host === entry.slice(1);
    return host === entry;
  });
}

/** Liefert den passenden Dispatcher für eine URL (Proxy oder Standard) */
function getDispatcher(url) {
  if (!proxyAgent) return undefined; // kein Proxy konfiguriert -> Standardverhalten
  const hostname = new URL(url).hostname;
  return isBypassed(hostname) ? undefined : proxyAgent;
}

/** Formatiert eine Zahl zweistellig, z.B. 3 -> "03" */
function pad2(n) {
  return String(n).padStart(2, "0");
}

/** Liefert { from, to } (ISO-Datum, YYYY-MM-DD) für den aktuellen Kalendermonat */
function getCurrentMonthRange() {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth(); // 0-basiert
  const from = `${year}-${pad2(month + 1)}-01`;
  const lastDay = new Date(year, month + 1, 0).getDate(); // letzter Tag des Monats
  const to = `${year}-${pad2(month + 1)}-${pad2(lastDay)}`;
  return { from, to };
}

// Wenn weder FORMIO_DATE_FROM noch FORMIO_DATE_TO gesetzt sind, automatisch
// den aktuellen Monat auswerten statt alle Submissions zu laden.
const envDateFrom = process.env.FORMIO_DATE_FROM || "";
const envDateTo = process.env.FORMIO_DATE_TO || "";
for (const [name, value] of [["FORMIO_DATE_FROM", envDateFrom], ["FORMIO_DATE_TO", envDateTo]]) {
  if (value && !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    console.error(`Fehler: ${name} muss im Format JJJJ-MM-TT stehen (z.B. 2026-01-31), gefunden: "${value}".`);
    process.exit(1);
  }
}
let resolvedDateFrom = envDateFrom;
let resolvedDateTo = envDateTo;

if (!envDateFrom && !envDateTo) {
  const currentMonth = getCurrentMonthRange();
  resolvedDateFrom = currentMonth.from;
  resolvedDateTo = currentMonth.to;
  console.log(
    `✔ Kein Zeitraum konfiguriert – werte automatisch aktuellen Monat aus: ${resolvedDateFrom} bis ${resolvedDateTo}`
  );
}

const CONFIG = {
  // Basis-URL deines Projekts, z.B. "https://mein-projekt.form.io"
  BASE_URL: process.env.FORMIO_BASE_URL || "",

  // --- Option A: API-Key ---
  API_KEY: process.env.FORMIO_API_KEY || "", // leer lassen, wenn Login genutzt wird

  // --- Option B: Login (nur nötig, wenn API_KEY leer ist) ---
  EMAIL: process.env.FORMIO_EMAIL || "",
  PASSWORD: process.env.FORMIO_PASSWORD || "",

  // Zeitraum (ISO-Datum). Wenn in der .env leer gelassen, wird automatisch
  // der aktuelle Kalendermonat verwendet (siehe getCurrentMonthRange oben).
  // Um wirklich ALLE Submissions zu laden, explizit ein weites Datum setzen,
  // z.B. FORMIO_DATE_FROM=2000-01-01
  DATE_FROM: resolvedDateFrom, // z.B. "2026-01-01"
  DATE_TO: resolvedDateTo,     // z.B. "2026-12-31"

  // Montage der ersten und letzten ISO-Woche des Zeitraums. Nur Wochen zwischen
  // diesen Montagen werden geschrieben, damit Wochenwerte vollständig sind.
  WEEK_WINDOW_FROM: resolvedDateFrom ? getIsoMonday(resolvedDateFrom) : "",
  WEEK_WINDOW_TO: resolvedDateTo ? getIsoMonday(resolvedDateTo) : "",

  // Seitengröße für die Paginierung (form.io erlaubt i.d.R. bis 1000)
  PAGE_SIZE: Number(process.env.FORMIO_PAGE_SIZE) || 1000,

  // Retry-Verhalten bei vorübergehenden Fehlern (502/503/504/429, Netzwerkfehler)
  MAX_RETRIES: Number(process.env.FORMIO_MAX_RETRIES) || 5,
  RETRY_BASE_DELAY_MS: Number(process.env.FORMIO_RETRY_BASE_DELAY_MS) || 1000,

  // Formulare ausschließen, deren Titel/Name/Pfad einen dieser Begriffe enthält
  // (kommagetrennt, Groß-/Kleinschreibung wird ignoriert), z.B. "_WARTUNG,_TEST"
  EXCLUDE_NAME_CONTAINS: (process.env.FORMIO_EXCLUDE_NAME_CONTAINS || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean),

  // CSV-Ausgabe: Standard ist Reports/formio-weekly-stats-<kunde>.csv, damit sich
  // die Abruf-Jobs der Kunden nicht gegenseitig überschreiben
  CSV_OUTPUT_PATH:
    process.env.FORMIO_CSV_OUTPUT_PATH ||
    path.resolve(__dirname, "Reports", `formio-weekly-stats-${CUSTOMER}.csv`),
};

// Grundlegende Validierung der Konfiguration
if (!CONFIG.BASE_URL) {
  console.error(
    "Fehler: FORMIO_BASE_URL ist nicht gesetzt. Bitte in der .env-Datei konfigurieren."
  );
  process.exit(1);
}
if (!CONFIG.API_KEY && !(CONFIG.EMAIL && CONFIG.PASSWORD)) {
  console.error(
    "Fehler: Weder FORMIO_API_KEY noch FORMIO_EMAIL/FORMIO_PASSWORD sind gesetzt."
  );
  process.exit(1);
}

// -----------------------------------------------------------------------

let authToken = null; // wird bei Login-Auth gesetzt

/** Kurze Pause (in ms) */
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// HTTP-Statuscodes, bei denen sich ein Retry lohnt (vorübergehende Serverfehler)
const RETRYABLE_STATUS_CODES = new Set([429, 502, 503, 504]);

/**
 * Wrapper um fetch(), der bei vorübergehenden Fehlern (502/503/504/429 oder
 * Netzwerkfehlern wie Timeouts) automatisch mit exponentiellem Backoff erneut versucht.
 */
async function fetchWithRetry(url, options = {}, context = "") {
  let lastError;

  for (let attempt = 1; attempt <= CONFIG.MAX_RETRIES; attempt++) {
    try {
      const res = await fetch(url, options);

      if (res.ok) return res;

      if (RETRYABLE_STATUS_CODES.has(res.status) && attempt < CONFIG.MAX_RETRIES) {
        const delay = CONFIG.RETRY_BASE_DELAY_MS * 2 ** (attempt - 1);
        console.warn(
          `⚠ ${context || url}: ${res.status} ${res.statusText} – Versuch ${attempt}/${CONFIG.MAX_RETRIES}, erneut in ${delay}ms...`
        );
        await sleep(delay);
        continue;
      }

      // Kein Retry-Kandidat oder letzter Versuch -> Fehler mit Response zurückgeben
      return res;
    } catch (err) {
      // Netzwerkfehler (z.B. Timeout, Verbindungsabbruch)
      lastError = err;
      if (attempt < CONFIG.MAX_RETRIES) {
        const delay = CONFIG.RETRY_BASE_DELAY_MS * 2 ** (attempt - 1);
        console.warn(
          `⚠ ${context || url}: ${err.message} – Versuch ${attempt}/${CONFIG.MAX_RETRIES}, erneut in ${delay}ms...`
        );
        await sleep(delay);
      }
    }
  }

  throw lastError || new Error(`Alle ${CONFIG.MAX_RETRIES} Versuche fehlgeschlagen: ${context || url}`);
}


function buildHeaders() {
  const headers = { "Content-Type": "application/json" };
  if (CONFIG.API_KEY) {
    headers["x-token"] = CONFIG.API_KEY;
  } else if (authToken) {
    headers["x-jwt-token"] = authToken;
  }
  return headers;
}

/** Loggt sich ein, falls kein API-Key konfiguriert ist */
async function loginIfNeeded() {
  if (CONFIG.API_KEY) return;

  const url = `${CONFIG.BASE_URL}/user/login`;
  const res = await fetchWithRetry(
    url,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        data: { email: CONFIG.EMAIL, password: CONFIG.PASSWORD },
      }),
      dispatcher: getDispatcher(url),
    },
    "Login"
  );

  if (!res.ok) {
    throw new Error(`Login fehlgeschlagen: ${res.status} ${res.statusText}`);
  }

  authToken = res.headers.get("x-jwt-token");
  if (!authToken) {
    throw new Error("Login erfolgreich, aber kein x-jwt-token erhalten.");
  }
  console.log("✔ Login erfolgreich.");
}

/** Holt die Liste aller Formulare im Projekt */
async function getForms() {
  const url = `${CONFIG.BASE_URL}/form?type=form&limit=1000`;
  const res = await fetchWithRetry(
    url,
    {
      headers: buildHeaders(),
      dispatcher: getDispatcher(url),
    },
    "Formularliste"
  );
  if (!res.ok) {
    throw new Error(`Formulare konnten nicht geladen werden: ${res.status} ${res.statusText}`);
  }
  return res.json(); // Array von Formular-Objekten mit u.a. { _id, title, path }
}

/** Holt alle Submissions eines Formulars (mit Paginierung & optionalem Datumsfilter) */
async function getAllSubmissions(formPath) {
  let all = [];
  let skip = 0;

  while (true) {
    const params = new URLSearchParams({
      limit: String(CONFIG.PAGE_SIZE),
      skip: String(skip),
      sort: "created",
      // nur die benötigten Felder laden (keine Formulardaten, also keine personenbezogenen Inhalte)
      select: "created,metadata.origin,metadata.referrer",
    });
    // ein Tag Puffer auf beiden Seiten, damit Berliner Tagesgrenzen (UTC-Speicherung) erfasst werden
    if (CONFIG.WEEK_WINDOW_FROM) params.append("created__gte", addDays(CONFIG.WEEK_WINDOW_FROM, -1));
    if (CONFIG.WEEK_WINDOW_TO) params.append("created__lte", addDays(CONFIG.WEEK_WINDOW_TO, 7));

    const url = `${CONFIG.BASE_URL}/${formPath}/submission?${params.toString()}`;
    const res = await fetchWithRetry(
      url,
      {
        headers: buildHeaders(),
        dispatcher: getDispatcher(url),
      },
      `Submissions "${formPath}" (skip=${skip})`
    );

    if (!res.ok) {
      throw new Error(
        `Submissions für "${formPath}" konnten nicht geladen werden: ${res.status} ${res.statusText}`
      );
    }

    const batch = await res.json();
    all = all.concat(batch);

    if (batch.length < CONFIG.PAGE_SIZE) break; // letzte Seite erreicht
    skip += CONFIG.PAGE_SIZE;
  }

  return all;
}

/** Verschiebt ein Datum "YYYY-MM-DD" um n Tage */
function addDays(day, n) {
  const [y, m, d] = day.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

/** Liefert den Montag der ISO-Kalenderwoche eines Datums "YYYY-MM-DD" */
function getIsoMonday(day) {
  const [y, m, d] = day.split("-").map(Number);
  const weekday = new Date(Date.UTC(y, m - 1, d)).getUTCDay() || 7;
  return addDays(day, 1 - weekday);
}

/** Berechnet ISO-Kalenderwoche im Format "YYYY-KWnn" für ein Datum "YYYY-MM-DD" */
function getISOWeekLabel(day) {
  const thursday = addDays(getIsoMonday(day), 3);
  const [y, m, d] = thursday.split("-").map(Number);
  const dayOfYear = (Date.UTC(y, m - 1, d) - Date.UTC(y, 0, 1)) / 86400000 + 1;
  return `${y}-KW${pad2(Math.ceil(dayOfYear / 7))}`;
}

// form.io speichert "created" in UTC; ausgewertet wird in der Berliner Zeit
const BERLIN_DAY = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Europe/Berlin",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

/** Liefert den Kalendertag in Berliner Zeit im Format "YYYY-MM-DD" */
function getBerlinDay(date) {
  return BERLIN_DAY.format(date);
}

const BERLIN_CLOCK = new Intl.DateTimeFormat("en-US", {
  timeZone: "Europe/Berlin",
  weekday: "short",
  hour: "2-digit",
  hourCycle: "h23",
});
const WEEKDAY_INDEX = { Mon: 0, Tue: 1, Wed: 2, Thu: 3, Fri: 4, Sat: 5, Sun: 6 };

/** Liefert Wochentag (0 = Montag) und Stunde (0-23) in der Berliner Zeit */
function getBerlinWeekdayHour(date) {
  const parts = Object.fromEntries(BERLIN_CLOCK.formatToParts(date).map((p) => [p.type, p.value]));
  return { weekday: WEEKDAY_INDEX[parts.weekday], hour: Number(parts.hour) };
}

/**
 * Ermittelt den Host (z.B. "meine.aok.de") der aufrufenden Seite aus den Metadaten.
 * Fehlende oder ungültige Angaben werden als "(unbekannt)" gezählt.
 */
function getHostFromMetadata(metadata = {}) {
  for (const value of [metadata.origin, metadata.referrer]) {
    if (!value) continue;
    try {
      return new URL(value).hostname;
    } catch {
      // ungültige URL: nächsten Wert probieren
    }
  }
  return "(unbekannt)";
}

/** Schreibt die Statistik als CSV-Datei */
function writeCsv(filePath, stats, allWeeks, formTitles) {
  const fs = require("fs");
  const path = require("path");

  const dir = path.dirname(filePath);
  if (dir && dir !== ".") {
    fs.mkdirSync(dir, { recursive: true });
  }

  const header = ["Formular", ...allWeeks].join(";");
  const rows = Object.keys(stats).map((formId) => {
    const title = formTitles[formId] || formId;
    const counts = allWeeks.map((week) => stats[formId][week] || 0);
    return [title, ...counts].join(";");
  });
  fs.writeFileSync(filePath, [header, ...rows].join("\n"), "utf-8");
  console.log(`✔ CSV geschrieben: ${filePath}`);
}

/** Gibt die Statistik als lesbare Tabelle in der Konsole aus */
function printTable(stats, allWeeks, formTitles) {
  const table = {};
  for (const formId of Object.keys(stats)) {
    const title = formTitles[formId] || formId;
    table[title] = {};
    for (const week of allWeeks) {
      table[title][week] = stats[formId][week] || 0;
    }
  }
  console.table(table);
}

/**
 * Prüft, ob ein Formular anhand von Titel, Name oder Pfad ausgeschlossen werden soll.
 * Vergleich erfolgt case-insensitive als Teilstring-Suche.
 */
function isExcluded(form) {
  if (CONFIG.EXCLUDE_NAME_CONTAINS.length === 0) return false;

  const haystack = [form.title, form.name, form.path]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();

  return CONFIG.EXCLUDE_NAME_CONTAINS.some((needle) =>
    haystack.includes(needle.toLowerCase())
  );
}

async function main() {
  console.log("Starte Auswertung...");
  await loginIfNeeded();

  const allForms = await getForms();
  console.log(`✔ ${allForms.length} Formular(e) gefunden.`);

  const forms = allForms.filter((form) => !isExcluded(form));
  const excludedCount = allForms.length - forms.length;
  if (excludedCount > 0) {
    console.log(
      `✔ ${excludedCount} Formular(e) durch Namensfilter ausgeschlossen (${CONFIG.EXCLUDE_NAME_CONTAINS.join(", ")}).`
    );
  }

  // stats: { formId: { "2026-KW01": 5, "2026-KW02": 3, ... } }
  const stats = {};
  // monthlyStats: { formId: { "2026-01": 5, "2026-02": 3, ... } }
  const monthlyStats = {};
  const formTitles = {};
  const weekSet = new Set();
  const monthSet = new Set();
  // Wochentag/Stunde und Herkunft, über alle Formulare eines Kunden summiert
  const heatmapCounts = new Map();
  const sourceCounts = new Map();

  for (const form of forms) {
    formTitles[form._id] = form.title;
    console.log(`→ Lade Submissions für "${form.title}" (${form.path})...`);

    const submissions = await getAllSubmissions(form.path);
    stats[form._id] = {};
    monthlyStats[form._id] = {};

    for (const submission of submissions) {
      const created = new Date(submission.created);
      const day = getBerlinDay(created);

      const weekMonday = getIsoMonday(day);
      const inWeekWindow =
        (!CONFIG.WEEK_WINDOW_FROM || weekMonday >= CONFIG.WEEK_WINDOW_FROM) &&
        (!CONFIG.WEEK_WINDOW_TO || weekMonday <= CONFIG.WEEK_WINDOW_TO);
      if (inWeekWindow) {
        const week = getISOWeekLabel(day);
        weekSet.add(week);
        stats[form._id][week] = (stats[form._id][week] || 0) + 1;
      }

      const inDayRange =
        (!CONFIG.DATE_FROM || day >= CONFIG.DATE_FROM) && (!CONFIG.DATE_TO || day <= CONFIG.DATE_TO);
      if (!inDayRange) continue;

      const month = day.slice(0, 7);
      monthSet.add(month);
      monthlyStats[form._id][month] = (monthlyStats[form._id][month] || 0) + 1;

      const { weekday, hour } = getBerlinWeekdayHour(created);
      const heatKey = `${month}|${weekday}|${hour}`;
      const heat = heatmapCounts.get(heatKey) || { month, weekday, hour, count: 0 };
      heat.count += 1;
      heatmapCounts.set(heatKey, heat);

      const host = getHostFromMetadata(submission.metadata);
      const formTitle = form.title || form._id;
      const sourceKey = `${month}|${host}|${formTitle}`;
      const src = sourceCounts.get(sourceKey) || { month, host, form_title: formTitle, count: 0 };
      src.count += 1;
      sourceCounts.set(sourceKey, src);
    }

    console.log(`   ${submissions.length} Submission(s) verarbeitet.`);
  }

  const allWeeks = Array.from(weekSet).sort();
  const allMonths = Array.from(monthSet).sort();

  console.log("\n=== Statistik: Submissions pro Woche und Formular ===\n");
  printTable(stats, allWeeks, formTitles);

  writeCsv(CONFIG.CSV_OUTPUT_PATH, stats, allWeeks, formTitles);

  const { rowsWritten, submissionsTotal } = upsertWeeklyStats(CUSTOMER, stats, formTitles, allWeeks, {
    from: CONFIG.DATE_FROM,
    to: CONFIG.DATE_TO,
  });
  console.log(
    `✔ Datenbank aktualisiert (Kunde "${CUSTOMER}"): ${rowsWritten} Zeile(n), ${submissionsTotal} Submission(s) gesamt.`
  );

  const monthlyResult = upsertMonthlyStats(CUSTOMER, monthlyStats, formTitles, allMonths);
  console.log(
    `✔ Monatsstatistik aktualisiert (Kunde "${CUSTOMER}"): ${monthlyResult.rowsWritten} Zeile(n), ${monthlyResult.submissionsTotal} Submission(s) gesamt.`
  );

  replaceActivityStats(CUSTOMER, allMonths, [...heatmapCounts.values()], [...sourceCounts.values()]);
  console.log(
    `✔ Wochentag/Stunde und Herkunft aktualisiert (Kunde "${CUSTOMER}"): ${heatmapCounts.size} Zeitfenster, ${sourceCounts.size} Herkunfts-Kombination(en).`
  );
}

main().catch((err) => {
  console.error("Fehler:", err.message);
  if (err.cause) {
    console.error("Ursache:", err.cause);
  }
  process.exit(1);
});